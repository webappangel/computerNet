
export const homeSelectors = {
    general: {
    },
    componentSearch: {
        general: {
            searchOptionArea: ".searchtabtotalbox",
            searchTabMenu: ".searchtab_menu",
            searchTabContent: "#nav-tabContent1",
            optionsContainer: ".desktop_area_on .searchtabgrouplist",
            
            // pax composition
            paxOneRoom: '.compositiondropdown_area',
            plusAdult: '.compositiondropdown_box:nth-child(1) .paxplus',
            minusAdult: '.compositiondropdown_box:nth-child(1) .paxminus',
            valueAdult: '.compositiondropdown_box:nth-child(1) .pax',
            plusChild: '.compositiondropdown_box:nth-child(2) .paxplus',
            minusChild: '.compositiondropdown_box:nth-child(2) .paxminus',
            valueChild: '.compositiondropdown_box:nth-child(2) .pax',
            plusInfant: '.compositiondropdown_box:nth-child(3) .paxplus',
            minusInfant: '.compositiondropdown_box:nth-child(3) .paxminus',
            valueInfant: '.compositiondropdown_box:nth-child(3) .pax',
            confirmPax: '.btn-group-area .save_btn',

            // search button
            btnSearch: '#nav-tabContent1 .tab-pane.active > .desktop_area_on .btnlarchesa',
        },
        flyingCarpet: {
            btnSearchCategory: ".nav-tabs > button[data-bs-target='#vacation_pack']",
            containerSearchOption: "#vacation_pack.tab-pane",
            optionDestination: (optionsContainer) => `${optionsContainer} > .btn-group:nth-child(1)`,
            optionRange: (optionsContainer) => `${optionsContainer} > .btn-group:nth-child(2)`,
            optionComposition: (optionsContainer) => `${optionsContainer} > .btn-group:nth-child(3)`,
        },
        flightOnly: {
            btnSearchCategory: ".nav-tabs > button[data-bs-target='#Flight_Only']",
            containerSearchOption: "#Flight_Only.tab-pane",
            typeFO: ".searchnavtotalmenu",
            optionDestination: (optionsContainer) => `${optionsContainer} .btn-group:nth-child(1)`,
            optionRange: (optionsContainer) => `${optionsContainer} .btn-group:nth-child(2)`,
            optionComposition: (optionsContainer) => `${optionsContainer} .btn-group:nth-child(3)`,
        },
        organizedTour: {

        }
    }
}