export const searchResultSelectors = {
    general: {
        // searchOptionArea: ".searchtabtotalbox",
        // searchTabMenu: ".searchtab_menu",
        // searchTabContent: "#nav-tabContent1",
        optionsContainer: ".desktop_area_on .searchtabgrouplist",
        
        // pax composition
        // paxOneRoom: '.compositiondropdown_area',
        // plusAdult: 'compositiondropdown_box:nth-child(1) .paxplus',
        // minusAdult: 'compositiondropdown_box:nth-child(1) .paxminus',
        // valueAdult: 'compositiondropdown_box:nth-child(1) .pax',
        // plusChild: 'compositiondropdown_box:nth-child(2) .paxplus',
        // minusChild: 'compositiondropdown_box:nth-child(2) .paxminus',
        // valueChild: 'compositiondropdown_box:nth-child(2) .pax',
        // plusInfant: 'compositiondropdown_box:nth-child(3) .paxplus',
        // minusInfant: 'compositiondropdown_box:nth-child(3) .paxminus',
        // valueInfant: 'compositiondropdown_box:nth-child(3) .pax',
        // confirmPax: '.btn-group-area .save_btn',

        // search button
        btnSearch: '#nav-tabContent1 .tab-pane.active > .desktop_area_on .btnlarchesa',
    },
    componentSearch: {
        general: {
            
        },
        flyingCarpet: {
            
        },
        flightOnly: {
            desktop: {
                // search panel
                searchPanel: '.innerbannerarea .directflightsonly_area',
                searchOptionsPanel: '.innerbannerarea .directflightsonly_area .directflightsonly_innerbox',
                containerSearchOption: "#Flight_Only.tab-pane",
                typeFO: ".searchnavtotalmenu",
                optionDestination: (optionsContainer) => `${optionsContainer} .btn-group:nth-child(1)`,
                optionRange: (optionsContainer) => `${optionsContainer} .btn-group:nth-child(2)`,
                optionComposition: (optionsContainer) => `${optionsContainer} .btn-group:nth-child(3)`,

                // search result
                areaSearchResult: '.searchresults_area',

                selSearchResultLabel: '.searchresults_topber h2',

                contFilter: '.resultmultipledateslist-card',

                contSearchResult: '.resultlist-left',
                contOneFlight: '.resultspageflights',
                selFlightInfo: '.searchresultbox_right .searchresultbox_two',
                selPriceFlight: '.searchresultbox_left',
                selExpandDetailFlight: '.Closedetail_btn',
                contDetailFlight: '.flightdetailscollapse',
                selDetailFlightInfo: '.flightdetails_item',
                selGoBook: '.btnarea > a.btn-warning',
            },
            mobile: {

            }
        },
        organizedTour: {

        }
    }
}