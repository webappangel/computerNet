const passenger = () => {
    const contOrderDetail: string = '.Orderdetails_body',
        contInfoFlight: string = '.Orderdetails_minibox';

    const contDetailHotel: string = `${contOrderDetail} .order_hotel_detail_area`;
    
    const contPrice: string = `${contOrderDetail} .total_box`;

    const contBookDetail: string = '.flightbooking_form_rightbox';

    return {
        general: {
            contOrderDetail,            
        },
        components: {
            general: {
                paxComposition: {
                    selLabelPax: `${contOrderDetail} .Orderdetails_body_top p`,
                },
                detailFlights: {
                    selDetailFlights: `${contInfoFlight} .Orderdetails_mini_item`,
                    selBtnExpand: `.Orderdetails_mini_titlle.collapsed`,
                },
                detailPrice: {
                    contPrice,
                },
                paxItem: {
                    selPassenger: `${contBookDetail} .flightformbox .flightformbox_itembox`,
                }
                
            },
            flyingCarpet: {
                detailHotel: {
                    contDetailHotel,
                    selCheckIn: `${contDetailHotel} > .hotel-info-inner .checkin`,
                    selCheckOut: `${contDetailHotel} > .hotel-info-inner .checkout`,
                },                
            },
            flightOnly: {

            },
            organizedTour: {

            }
        }
    }
}

export const passengerSelectors = passenger();