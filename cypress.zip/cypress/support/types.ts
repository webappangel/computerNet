export type JSONValue = string | number | boolean | null | JSONValue[] | { [key: string]: JSONValue };

export type TypeDevice = {
    name: string;
    viewport: [number, number] | string;
  }

type MonthKey = '01' | '02' | '03' | '04' | '05' | '06' | '07' | '08' | '09' | '10' | '11' | '12';

export type MonthTranslations = Record<MonthKey, { en: string; he: string }>;

export type ItemAPI = {
    alias: string,
    url: string,
    method: string,
}

export type DestinationSummary = {
    destinationCodes: string[];
    hotelIds: string[];
}

export type ExactDate = {
    startDate: string;
    endDate: string;
}

export type StateWeek = {
    midweek: boolean;
    weekend: boolean;
}

export type RangeSummary = ExactDate & StateWeek & {
    numNights: number[];
    wholeMonths: string[];
}

export type CompositionSummary = {
    adults: number;
    children: number;
    infants: number;
    agesChildren: number[];
    agesInfants: number[];
}

export type SearchOption = {
    typeFO?: number;
    destinations?: DestinationSummary;
    range?: RangeSummary;
    composition?: CompositionSummary[];
}

export type OptionSearch = {
    originCodes?: string,
    destinationCodes?: string,
    hotelIds?: string,
    subCategories?: string,
    calendarType?: string,
    dates?: string,
    fullMonths?: string,
    paxByRoom?: string,
    durations?: string,
    flightDirection?: string,
    category?: string,
    weekend?: boolean,
    midweek?: boolean,
}

export type OptionProduct = {
    packCateg?: string,
    destinationCodes?: string,
    hotelIds?: string,
    subCategories?: string,
    calendarType?: string,
    fullMonths?: string,
    paxByRoom?: string,
}

export type FormatOptions = {
	withWeekday?: boolean;
	withYear?: boolean;
	withTime?: boolean;
};