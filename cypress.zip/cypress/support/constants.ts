import {TypeDevice, MonthTranslations, ItemAPI} from '../support/types'

// devices
export const devices: TypeDevice[] = [
  { name: 'Large Desktop 1440', viewport: [1440, 1200] },
  // { name: 'Desktop 1200', viewport: [1200, 800] },
  // { name: 'Tablets (Landscape) 992', viewport: [992, 800] },
  // { name: 'Tablets (Portrait) 768', viewport: [768, 800] },
  // { name: 'Mobile (Large) 576', viewport: [576, 800] },
  // { name: 'Mobile (Small) 476', viewport: [476, 800] },
  // { name: 'Mobile iPhone 6', viewport: 'iphone-6' },
  // { name: 'Mobile iPhone 4', viewport: 'iphone-4' },
];

export const maxResponseTime = 30000;
export const apiList: ItemAPI[] = [
  { alias: 'fetchAgentData', url: '**api/agencyContents/byHost/*', method: 'GET'},
  { alias: 'fetchDestinationData', url: '**api/destinationEx/*', method: 'GET' },
  { alias: 'fetchEffectDestsData', url: '**api/deal/inEffectLanding/dests*', method: 'GET'},
  { alias: 'fetchfooterItemData', url: '**api/footerItem/pageList', method: 'GET' },
  { alias: 'fetchfooterCategoryData', url: '**api/footerCategory/activeOnly', method: 'GET' },
  { alias: 'fetchAreaData', url: '**api/area', method: 'GET' },
  { alias: 'fetchInPageBannerData', url: '**api/pageBanner/search', method: 'POST' },
  { alias: 'fetchPackSubCategoryData', url: '**api/packSubCategory/withDest', method: 'GET' },
  { alias: 'fetchinEffectHomeDealTypesData', url: '**api/deal/inEffectHome/dealTypes*', method: 'GET' },
  { alias: 'fetchPackCategoryTopData', url: '**api/operation/PackCategoryTop*', method: 'GET' },
  { alias: 'fetchInPackHotelsData', url: '**api/operation/packHotels*', method: 'GET' },
  { alias: 'fetchDynPackData', url: '**api/operation/dynPack/*', method: 'GET' },
  { alias: 'fetchHotelSupplierData', url: '**api/operation/dynPack/hotelSupplier', method: 'GET' },
  { alias: 'fetchPackageCategoryData', url: '**api/operation/dynPack/packageCategory', method: 'GET' },
  { alias: 'fetchHolidaysData', url: '**api/operation/packDates/holidays*', method: 'GET' },
  { alias: 'fetchDealTypeData', url: '**api/operation/dealType*', method: 'GET' },
];

export const apiListSearchResult: ItemAPI[] = [
  { alias: 'destinationData', url: '**api/destinationEx/*', method: 'GET'},
  { alias: 'searchVacation', url: '**api/operation/dynPack/search/vacation/*', method: 'POST'},
  { alias: 'searchFlight', url: '**api/operation/dynPack/search/flights/*', method: 'POST'},
]

export const labelNumber: string[] = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];

export const months: MonthTranslations = {
  '01': { en: 'January', he: 'ינואר' },
  '02': { en: 'February', he: 'פברואר' },
  '03': { en: 'March', he: 'מרץ' },
  '04': { en: 'April', he: 'אפריל' },
  '05': { en: 'May', he: 'מאי' },
  '06': { en: 'June', he: 'יוני' },
  '07': { en: 'July', he: 'יולי' },
  '08': { en: 'August', he: 'אוגוסט' },
  '09': { en: 'September', he: 'ספטמבר' },
  '10': { en: 'October', he: 'אוקטובר' },
  '11': { en: 'November', he: 'נובמבר' },
  '12': { en: 'December', he: 'דצמבר' },
};

export const monthsEn: Record<string, number> = {
  January: 1,
  February: 2,
  March: 3,
  April: 4,
  May: 5,
  June: 6,
  July: 7,
  August: 8,
  September: 9,
  October: 10,
  November: 11,
  December: 12,
};

export const monthsHe: Record<string, number> = {
  ינואר: 1,
  פברואר: 2,
  מרץ: 3,
  אפריל: 4,
  מאי: 5,
  יוני: 6,
  יולי: 7,
  אוגוסט: 8,
  ספטמבר: 9,
  אוקטובר: 10,
  נובמבר: 11,
  דצמבר: 12,
};

export const monthsHeShort: Record<string, number> = {
  ינו: 1,
  פבר: 2,
  מרץ: 3,
  אפר: 4,
  מאי: 5,
  יונ: 6,
  יול: 7,
  "אוג'": 8,
  "ספט'": 9,
  "אוק'": 10,
  "נוב'": 11,
  "דצמ'": 12,
};

export const monthsHeShortReverse: Record<number, string> = {
  1: "ינו'",
  2: "פבר'",
  3: "מרץ",
  4: "אפר'",
  5: "מאי",
  6: "יונ'",
  7: "יול'",
  8: "אוג'",
  9: "ספט'",
  10: "אוק'",
  11: "נוב'",
  12: "דצמ'",
};

export const monthsHeShortReverseOrigin: Record<number, string> = {
  1: "ינו",
  2: "פבר",
  3: "מרץ",
  4: "אפר",
  5: "מאי",
  6: "יונ",
  7: "יול",
  8: "אוג",
  9: "ספט",
  10: "אוק",
  11: "נוב",
  12: "דצמ",
};

export const monthsEnShort: Record<string, number> = {
  Jan: 1,
  Feb: 2,
  Mar: 3,
  Apr: 4,
  May: 5,
  Jun: 6,
  Jul: 7,
  Aug: 8,
  Sep: 9,
  Oct: 10,
  Nov: 11,
  Dec: 12,
};

export const weekdayNamesHe = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];


export const composition: Record<string, string> = {
	adults: 'מבוגרים',
	adult: 'מבוגר',
	children: 'ילדים',
	child: 'ילד',
	infants: 'תינוקות',
	infant: 'תינוק',
}

//////////////////////////////
export const apiListAll: ItemAPI[] = [
  { alias: 'fetchAgentData', url: '**api/agencyContents/byHost/*', method: 'GET'},
  { alias: 'fetchDestinationData', url: '**api/destinationEx/*', method: 'GET' },
  { alias: 'fetchEffectDestsData', url: '**api/deal/inEffectLanding/dests*', method: 'GET'},
  { alias: 'fetchfooterItemData', url: '**api/footerItem/pageList', method: 'GET' },
  { alias: 'fetchfooterCategoryData', url: '**api/footerCategory/activeOnly', method: 'GET' },
  { alias: 'fetchAreaData', url: '**api/area', method: 'GET' },
  { alias: 'fetchInPageBannerData', url: '**api/pageBanner/search', method: 'POST' },
  { alias: 'fetchPackSubCategoryData', url: '**api/packSubCategory/withDest', method: 'GET' },
  { alias: 'fetchinEffectHomeDealTypesData', url: '**api/deal/inEffectHome/dealTypes*', method: 'GET' },
  { alias: 'fetchPackCategoryTopData', url: '**api/operation/PackCategoryTop*', method: 'GET' },
  { alias: 'fetchInPackHotelsData', url: '**api/operation/packHotels*', method: 'GET' },
  { alias: 'fetchDynPackData', url: '**api/operation/dynPack/*', method: 'GET' },
  { alias: 'fetchHotelSupplierData', url: '**api/operation/dynPack/hotelSupplier', method: 'GET' },
  { alias: 'fetchPackageCategoryData', url: '**api/operation/dynPack/packageCategory', method: 'GET' },
  { alias: 'fetchHolidaysData', url: '**api/operation/packDates/holidays*', method: 'GET' },
  { alias: 'fetchDealTypeData', url: '**api/operation/dealType*', method: 'GET' },
  { alias: 'fetchInEffecHOmeV3', url: '**api/deal/inEffectHomeV3*', method: 'GET' },
	
	//search result
	{ alias: 'searchVacation', url: '**api/operation/dynPack/search/vacation/*', method: 'POST'},
  { alias: 'searchFlight', url: '**api/operation/dynPack/search/flights/*', method: 'POST'},
	
	//product page
  { alias: 'selectPackage', url: '**api/operation/dynPack/select*', method: 'POST' },
  
  //passenger page
  { alias: 'passengerDetail', url: '**api/operation/bookingData*', method: 'GET' },
  { alias: 'bookVacation', url: '**api/operation/dynPack/book/vacation*', method: 'POST' },

  //booking confirm
  { alias: 'cardCompleted', url: '**api/operation/dynPack/cardCompleted/*', method: 'POST' },
];
