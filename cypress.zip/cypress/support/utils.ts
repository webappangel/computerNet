import dayjs from 'dayjs';
dayjs.locale('he');

import { monthsEn, monthsHe, monthsHeShort, monthsEnShort, weekdayNamesHe, monthsHeShortReverse, monthsHeShortReverseOrigin } from "./constants";

import { FormatOptions } from './types'
import cypress from 'cypress';

// Remove unused import that's causing error
export * from  './composables/useFlightInfo'

export const convertMillToSec = (pMill: number): number => {
    return pMill/1000;
}

export const parseToISO = (
  dateStr: string,
  format: string = "DD MMM YYYY"
): string | null => {
  const parts = dateStr.trim().split(/[\s/-]+/); // Split by space, slash, or dash
  const formatParts = format.trim().split(/[\s/-]+/);

  if (parts.length !== formatParts.length) return null;

  let day: number | null = null;
  let month: number | null = null;
  let year: number | null = null;

  for (let i = 0; i < formatParts.length; i++) {
    const token = formatParts[i];
    const value = parts[i];

    switch (token) {
      case 'YYYY':
        year = Number(value);
        break;
      case 'DD':
        day = Number(value);
        break;
      case 'MMM': {
        const normalized = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase(); // Normalize case
        if (monthsEnShort[normalized]) {
					month = monthsEnShort[normalized];
				} else if (monthsEn[normalized]) {
					month = monthsEn[normalized];
				} else if (monthsHeShort[value]) {
					month = monthsHeShort[value];
				} else if (monthsHe[value]) {
					month = monthsHe[value];
				}
        break;
      }
      case 'MM':
        month = Number(value);
        break;
      default:
        return null; // Unsupported token
    }
  }

  if (!month || !day || !year || isNaN(day) || isNaN(month) || isNaN(year)) {
    return null;
  }

  const mm = String(month).padStart(2, '0');
  const dd = String(day).padStart(2, '0');
  return `${year}-${mm}-${dd}`;
};

export const generateUniqueRandomNumbers = (count: number, min: number, max: number): number[] => {
  const numbers = new Set<number>();
    
    while (numbers.size < count) {
        const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
        numbers.add(randomNumber);
    }
    
    return Array.from(numbers);
}

export const updateStateHistory = (kind:number, updates: Partial<Record<string, any>>, type: string = 'update') => {
	if(kind==1) {
		cy.readFile('cypress/history/history.json').then((data) => {
			if(type=='create') {
				data.push({...updates});
			} else if(type=='update') {
				let item = data[data.length-1];
				data[data.length-1] = {...item, ...updates};
			}
      cy.writeFile('cypress/history/history.json', data);
      console.log(data.length);
		})
	} else if(kind ==0) {
		cy.readFile('cypress/history/history_error.json', { log: false }).then((data) => {
			data = {...data, ...updates};
			cy.writeFile('cypress/history/history_error.json', data, { log: false });
		});
	}
}

export const getStatePage = (type: string): Cypress.Chainable<any> => {
  return cy.readFile('cypress/history/history.json').then((data) => {
		return data[data.length-1]?.[type] ?? '';
	})
}

export const parseQueryString = (url: string): Record<string, any> => {
  const queryString = url.split('?')[1]?.split('#')[0] || '';
  const hashString = url.split('#')[1] || '';

  const rawParams = {
    ...Object.fromEntries(new URLSearchParams(queryString).entries()),
    ...Object.fromEntries(new URLSearchParams(hashString).entries()),
  };

  const parsedParams: Record<string, any> = {};

  for (const [key, value] of Object.entries(rawParams)) {
    if (value === 'true') {
      parsedParams[key] = true;
    } else if (value === 'false') {
      parsedParams[key] = false;
    } else if (!isNaN(Number(value)) && value.trim() !== '') {
      parsedParams[key] = Number(value);
    } else {
      parsedParams[key] = value;
    }
  }

  return parsedParams;
}

export const onClickDOM = (
  selector: string,
  container?: string,
  options?: {
    force?: boolean;
    index?: number;
    repeat?: number;
    ensureVisible?: boolean;
    log?: boolean;
  }
): Cypress.Chainable => {
  const {
    index = 0,
    repeat = 1,
    ensureVisible = true,
    log = false,
    force = false
  } = options || {};

  const base = container
    ? cy.get(container).should('be.visible').find(selector)
    : cy.get(selector);

  return base.eq(index).then(($el) => {
    let chain = cy.wrap(null); // start empty chain
    for (let i = 0; i < repeat; i++) {
      chain = chain.then(() => {
        if (log) cy.log(`Click #${i + 1} on element [index ${index}]`);
        const wrapped = cy.wrap($el); // re-wrap to avoid stale elements
        return wrapped.then(($el) => {
          if (!$el.prop('disabled')) {
            if (ensureVisible) {
              return cy.wrap($el).scrollIntoView().click({ force });
            } else {
              return cy.wrap($el).click({ force });
            }
          } else {
            if (log) cy.log('Element is disabled, skipping click');
            return cy.wrap(null); // no-op to keep the Cypress chain intact
          }
        });
      });
    }
    return chain;
  });
};

// Format day name + date (dd/mm)
export const formatWithDayName = (strDate: string, format:string = 'DD/MM'): string => {
	const date = dayjs(strDate);
  const dayName = weekdayNamesHe[date.day()];
  const formattedDate = date.format(format);
  return `${dayName} ${formattedDate}`;
};

// חמישי 23/10 '11:00'
export const getDateTimeFlight = (strDatetime: string): string => {
	const original = dayjs(strDatetime);

	// Round down to the full hour
	const rounded = original.second(0);

	// Format parts
	const dayName = weekdayNamesHe[rounded.day()];
	const datePart = rounded.format('DD/MM');
	const timePart = rounded.format('HH:mm');
	return `${timePart} ${datePart} ${dayName}`;
}

//default : HH:mm YYYY MMM DD day
export function formatHebrewDate(dateStr: string, options: FormatOptions = {}): string {
  const date = dayjs(dateStr);

  const weekday = weekdayNamesHe[date.day()];
  const day = date.date().toString().padStart(2, '0');
  const month = monthsHeShortReverseOrigin[date.month() + 1];
  const year = date.year();
  const time = date.format('HH:mm');

  const parts = [];

  
  parts.push(`${day} ${month}`);
  if (options.withYear) parts.push(year.toString());
  if (options.withTime) parts.push(`'${time}'`);
  let strDate = parts.join(' ');
  if (options.withWeekday) strDate = `${weekday}, ${strDate}`;

  return strDate;
}

/**
 * Format a date string into a dynamic Hebrew-style format.
 * Supported placeholders: weekday, day, month, year, time
 */
export function strDateFormatHebrew(dateStr: string, format: string = 'time year month day weekday'): string {
  const date = dayjs(dateStr);
  if (!date.isValid()) return '';

  const map: Record<string, string> = {
    weekday: weekdayNamesHe[date.day()],
    day: date.date().toString().padStart(2, '0'),
    month: monthsHeShortReverseOrigin[date.month() + 1],
    year: date.year().toString(),
    time: `'${date.format('HH:mm')}'`,
  };

  return format
    .split(' ')
    .map(part => map[part] ?? part)
    .join(' ');
}