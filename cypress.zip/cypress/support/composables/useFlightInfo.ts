import dayjs from "dayjs";

export const propFlightAirline = (pFlightInfo: Record<string, any>): string => {
    return `${pFlightInfo?.excerpt?.airline ?? NaN}`
}

export const propAirportDepart = (pFlightInfo: Record<string, any>): string => {
    return pFlightInfo?.excerpt?.departure?.airport ?? NaN;
}

export const propAirportArrive = (pFlightInfo: Record<string, any>): string => {
    return pFlightInfo?.excerpt?.arrival?.airport ?? NaN
}

export const propFlightNumberFO = (pFlightInfo: Record<string, any>): string => {
    return `${propFlightAirline(pFlightInfo)}${pFlightInfo?.segmentExcerpts?.[0]?.flightNumber ?? NaN}`;
}

export const propFlightCityCode = (pFlightInfo: Record<string, any>): string => {
    return pFlightInfo?.excerpt?.departure?.city ?? pFlightInfo?.excerpt?.departure?.airport ?? NaN;
}

export const propFlightDepartureDate = (pFlightInfo: Record<string, any>): string => {
    return pFlightInfo?.excerpt?.departureDate ?? pFlightInfo?.departureDate ?? NaN;
}

export const propFlightDepartureTime = (pFlightInfo: Record<string, any>): string => {
    return pFlightInfo?.excerpt?.departure?.time ?? NaN;
}

export const propFlightArrivalDate = (pFlightInfo: Record<string, any>): string => {
    const departDate = dayjs(propFlightDepartureDate(pFlightInfo));
    return dayjs(departDate).add(pFlightInfo?.excerpt?.arrival?.dateAdjustment?? 0, 'day').toString();
}

export const propFlightArrivalTime = (pFlightInfo: Record<string, any>): string => {
    return pFlightInfo?.excerpt?.arrival?.time ?? NaN;
}

export const propDestCode = (pFlightInfo: Record<string, any>, direction: string): string => {
    const dirKey = direction == 'departure' ? 'departure' : 'arrival';
    return pFlightInfo?.excerpt?.[dirKey]?.city ?? pFlightInfo?.excerpt?.[dirKey]?.airport ?? NaN;
}
