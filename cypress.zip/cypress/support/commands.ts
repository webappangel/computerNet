// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

import { modeShow } from './constants';
import { updateStateHistory } from './utils';
import dayjs from 'dayjs';

declare global {
  namespace Cypress {
    interface Chainable<Subject = any> {
      /**
       * Clicks a link with the given href.
       */
      clickLink(href: string): Chainable<JQuery<HTMLElement>>;

      /**
       * Logs and shows the time spent.
       */
      showSpendTime(pMillTime: number, pLabel: string): Chainable<void>;

      /**
       * Verifies that a special option link contains the expected substring.
       */
      includeSpecialOptionLink(currCO: JQuery<HTMLElement>, specOpt: string): Chainable<void>;

      /**
       * get attribute of the dom with given selector and attribute
       */
      getAttr(selector: string, attr: string): Chainable<string>;

      /**
       * get value of the input with given selector
       */
      getValue(selector: string): Chainable<string>;

      /**
       * Setup timing for network requests
       */
      setupTiming(alias: string, url: string, method?: string, timings?: Map<string, TimingData>): Chainable<null>;
    }
  }
}

import {convertMillToSec} from './utils'

//deay for all command
if (modeShow) {
  const COMMAND_DELAY: number = 1000;
  const delayedCommands: Array<keyof Cypress.Chainable<any>> = [
    'click',
    'trigger',
    'scrollIntoView'
  ];
  for (const command of delayedCommands) {
    Cypress.Commands.overwrite(
      command,
      (originalFn: (...args: any[]) => Cypress.Chainable, ...args: any[]) => {
        const result = originalFn(...args);
        return new Cypress.Promise((resolve) => {
          setTimeout(() => resolve(result), COMMAND_DELAY);
        });
      }
    );
  }
}

//command to click the href link
Cypress.Commands.add('clickLink', (href: string): void => {
	cy.get(`a[href="${href}"]`).click();
})

Cypress.Commands.add('showSpendTime', (pMillTime: number, pLabel = ''): void=> {
	cy.log(`the time of ${pLabel} is ` + convertMillToSec(pMillTime));
})

type TimingData = { start: number; end: number };
Cypress.Commands.add('setupTiming', (alias: string, url: string, method: string = 'GET', timings: Map<string, TimingData> = new Map()) => {
  cy.intercept({ method, url }, (req) => {
    const timing = { start: Date.now(), end: 0 };
    timings.set(alias, timing);
    req.on('response', () => {
      timing.end = Date.now();
      console.log(`${alias} ==> ${timing.end - timing.start}`);
    });
  }).as(alias);
})

// Custom Command (optional)
Cypress.Commands.add('getAttr', (selector: string, attr: string): Cypress.Chainable<string> => {
  cy.log(`getAttr: ${selector} : ${attr}`);
  return cy.get(selector)
    .filter(':visible')
    .should('exist')
    .scrollIntoView()
    .should('be.visible')
    // .should('have.attr', attr)
    .invoke('attr', attr)
});

Cypress.Commands.add('getValue', (selector: string): Cypress.Chainable<string> => {
  return cy.get(selector)
    .filter(':visible')
    .should('exist')
    .scrollIntoView()
    .should('be.visible')
    // .should('have.attr', 'value')   // check that value attr exists
    .invoke('val');      
})

Cypress.Commands.add('includeSpecialOptionLink', (currCO: JQuery<HTMLElement>, specOpt: string) => {
  cy.wrap(currCO).invoke('attr', 'href').then((link: string | undefined) => {
    expect(link).to.include(specOpt);
  });
});

afterEach(function () {
  if (this.currentTest?.state === 'failed') {
    const currTime = dayjs().format('YYYY-MM-DD-HH-mm-ss');
    cy.url().then((currentUrl: string) => {
      updateStateHistory(0, {
        [currTime]: {
          url: currentUrl,
          error: {
            message: this.currentTest?.err?.message,
            stack: this.currentTest?.err?.stack,
            actual: this.currentTest?.err?.actual,
            expected: this.currentTest?.err?.expected,
            operator: this.currentTest?.err?.operator,
            codeFrame: this.currentTest?.err?.codeFrame,
          },
        }
      })
    })
    cy.screenshot(`${currTime}-${this.currentTest.title}`, { capture: 'runner' });
  }
});


