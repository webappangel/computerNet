import { PackKind } from '../../src/type'

describe('Search Panel', () => {
  beforeEach(() => {
    cy.visit('/')
    // Wait for the page to load
    cy.wait(2000)
  })

  describe('Desktop View', () => {
    beforeEach(() => {
      cy.viewport(1280, 720)
    })

    it('should display main search components', () => {
      // Check for the main search area
      cy.get('.searchbannerarea').should('be.visible')
      cy.get('.directflightsonly_area').should('be.visible')
      cy.get('.search-controls').should('be.visible')
    })

    it('should show search navigation list after category load', () => {
      // Initially should show loader
      cy.get('[type="search-panel"]').should('exist')
      
      // After loading, should show search nav list
      cy.get('SearchNavList').should('be.visible')
    })

    it('should display banner images and pagination', () => {
      cy.get('.banner-swiper').should('exist')
      cy.get('.swiper-slide').should('have.length.at.least', 1)
      cy.get('.swiper-pagination').should('be.visible')
    })

    it('should have working navigation buttons', () => {
      cy.get('.search-nav-top-button').should('be.visible')
      cy.get('.go-to-landing-page-button').should('be.visible')
    })
  })

  describe('Mobile View', () => {
    beforeEach(() => {
      cy.viewport('iphone-x')
    })

    it('should display mobile search components', () => {
      cy.get('.resultsflights-mobailseach').should('be.visible')
      cy.get('.directflightsonly_area').should('be.visible')
    })

    it('should toggle mobile search panel', () => {
      // Check if control button is visible
      cy.get('.searchtabtotalsmmalbox').should('be.visible')
      
      // Click change search button
      cy.get('.resultsflightsmobail-btn').click()
      
      // Verify search panel is shown
      cy.get('#myBox').should('be.visible')
    })
  })

  describe('Search Panel Categories', () => {
    it('should handle organized trips search', () => {
      // Wait for categories to load
      cy.get('SearchNavList').should('be.visible')
      
      // Check for organized trips tab
      cy.get(`[data-tab-id="${PackKind.org}"]`).should('exist')
    })

    it('should handle vacation packages search', () => {
      cy.get('SearchNavList').should('be.visible')
      cy.get(`[data-tab-id="${PackKind.pack}"]`).should('exist')
    })

    it('should handle flight search', () => {
      cy.get('SearchNavList').should('be.visible')
      cy.get(`[data-tab-id="${PackKind.fo}"]`).should('exist')
    })
  })

  describe('Search Panel Functionality', () => {
    it('should show destination text when available', () => {
      cy.get('.directflightsonly_area h1').should('exist')
    })

    it('should handle banner image loading', () => {
      // Check for banner loading state
      cy.get('.banner-loading').should('not.exist')
      
      // Check for loaded banner
      cy.get('.banner-slide').should('be.visible')
    })

    it('should have working promotion button', () => {
      cy.get('.go-to-landing-page-button').should('be.visible')
      cy.get('.go-to-landing-page-button').should('not.be.disabled')
    })
  })

  describe('Search Panel Interactions', () => {
    it('should handle banner slide changes', () => {
      // Wait for swiper to initialize
      cy.get('.banner-swiper').should('exist')
      
      // Check pagination functionality
      cy.get('.swiper-pagination-bullet').first().click()
      cy.get('.swiper-pagination-bullet-active').should('exist')
    })

    it('should maintain search panel state after navigation', () => {
      // Click a search option
      cy.get('SearchNavList').should('be.visible')
      
      // Verify the search panel maintains its state
      cy.get('.directflightsonly_area').should('be.visible')
    })
  })

  describe('Error States', () => {
    it('should handle category load failures gracefully', () => {
      // Force failure state
      cy.intercept('GET', '**/categories', {
        statusCode: 500,
        body: { error: 'Server error' }
      })
      
      cy.visit('/')
      
      // Should show appropriate error state or fallback
      cy.get('[type="search-panel"]').should('exist')
    })

    it('should handle banner image load failures', () => {
      // Force banner image failure
      cy.intercept('GET', '**/banner-images', {
        statusCode: 500,
        body: { error: 'Image load failed' }
      })
      
      cy.visit('/')
      
      // Should show fallback or error state
      cy.get('.banner-loading').should('not.exist')
    })
  })
}) 