import { numRun } from '../../support/global';
import { devices, apiListAll, maxResponseTime } from '../../support/constants';
import { parseToISO } from '../../support/utils';
import type { JSONValue } from '../../support/types';

import {testHomePage, testSearchResultPage} from './operation/vacation_pack';
import { testProductPage } from './operation/action_product';
import { testPassengerPage } from './operation/action_passenger';

const modeTest = Cypress.env('modeTest');
const modeShow = Cypress.env('modeShow');
const makePNR = Cypress.env('makePNR');
const modeWorking = Cypress.env('modeWorking');

const timings = new Map();
const extraData: JSONValue = {
  hotelData: {},
  destinationData: {},
};

console.clear();

devices.forEach(device => {
  describe(`Testing on ${device.name}`, () => {
    const isMobile = device.name.includes('Mobile');
    let startTime: number = performance.now();

    beforeEach(() => {
		apiListAll.forEach(({ alias, url, method }) => {
			cy.intercept({ method: method as 'GET' | 'POST', url }, (req) => {
				timings.set(alias, { start: Date.now() });
				req.on('response', (res) => {
					timings.get(alias).end = Date.now();
					console.log(`${alias} ==> ${timings.get(alias).end - timings.get(alias).start}`);
					switch(alias){
						case 'fetchDestinationData':
							extraData.destinationData = res.body.data;
							console.log(extraData.destinationData);
							break;
						case 'searchVacation':
							extraData.hotelData = res.body.data;
							console.log(extraData.hotelData);							
							break;
					}
				});
			}).as(alias);
		})
			
      
		if (Array.isArray(device.viewport)) {
			const [width, height]: [number, number] = device.viewport;
			cy.viewport(width, height);
		} else {
			cy.viewport(device.viewport as Cypress.ViewportPreset);
		}
			
    });

	const ctRepeat = (makePNR || modeWorking) ? 1 : numRun;
	for (let i = 0; i < ctRepeat; i++) {
		it('test on home page', () => {
			testHomePage(isMobile, modeTest, extraData);
		});
		
		it('test on search result page', () => {
			testSearchResultPage(isMobile, modeTest, extraData);
		})
		
		it('test on product page', () => {
			testProductPage(isMobile, modeTest, extraData);
		})

		it('test on passenger page', () => {
			testPassengerPage(isMobile, modeTest, extraData);
		})
	}
		
		
		
		// it('test for search result page', () => {
			// cy.wait('@pageSearchResult').then((url: string) => {
				// loadedPage(url, 'VP', isMobile, extraData);
			// })
		// })
  });
	
	
})