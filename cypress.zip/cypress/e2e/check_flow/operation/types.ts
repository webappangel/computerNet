export type DestinationSummary = {
  destinationCodes: string[],
  hotelIds: string[];
};

export type RangeSummary = {
	startDate: string,
	endDate: string,
	midweek: boolean,
	weekend: boolean,
	numNights: number[],
	wholeMonths: string[],
};

export type ExactDate = {
	stateDate: string,
	endDate: string,
}

export type StateWeek = {	
	midweek: boolean,
	weekend: boolean,
}

export type CompositionSummary = {
	adult: number,
	child: number,
	infant: number,
}

export type SearchOption = {
	destinations: DestinationSummary,
	range: RangeSummary,
	composition: CompositionSummary,
}

