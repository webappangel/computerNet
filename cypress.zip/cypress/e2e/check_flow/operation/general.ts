const modeTest = Cypress.env('modeTest');
const modeShow = Cypress.env('modeShow');

import {
    generateUniqueRandomNumbers,
    onClickDOM,
    parseToISO,
} from '../../../support/utils';

import {
    DestinationSummary,
    ExactDate,
    StateWeek,
    RangeSummary,
    CompositionSummary,
    SearchOption,
} from '../../../support/types';

import { selectTypeFO } from './flight_only';

import { homeSelectors } from '../../../selectors/home.css.ts';

export const onClickDuringAvailable = (
  selector: string,
  container: string,
  options?: {
    isMobile?: boolean;
    ensureVisible?: boolean;
    log?: boolean;
    maxTries?: number;
    delayMs?: number;
  }
): Cypress.Chainable<number> => {
  const {
    isMobile = false,
    ensureVisible = true,
    log = false,
    maxTries = 10,
    delayMs = 500,
  } = options || {};

  let clickCount = 0;

  const clickNext = (): Cypress.Chainable<number> => {
    return cy.get(container).then($container => {
      const $el = $container.find(selector);
      const shouldClick = $el.length > 0 && $el.is(':visible') && !$el.is(':disabled');

      if (shouldClick && clickCount < maxTries) {
        if (log) {
          cy.log(`Clicking element ${selector} (click #${clickCount + 1})`);
        }

        let action = cy.wrap($el.first(), { log: false });

        if (ensureVisible) {
          action = action.scrollIntoView();
        }

        return action
          .click({ force: true })
          .wait(delayMs)
          .then(() => {
			clickCount++;
			if(clickCount<maxTries) {
				return clickNext();
			} else {
				return cy.wrap(clickCount);
			}
          });
      } else {
        if (log) {
          cy.log(`Stopped after ${clickCount} click(s).`);
        }
        return cy.wrap(clickCount);
      }
    });
  };

  return clickNext();
};

export const selectDestination = (
  container: string,
  options?: {
    withHotelId?: boolean;
    isMobile?: boolean;
    ensureVisible?: boolean;
    log?: boolean;
  }
): Cypress.Chainable<DestinationSummary> => {
	const {
		withHotelId = false,
		isMobile = false,
		ensureVisible = true,
		log = false,
	} = options ?? {};

	const stateDestination: DestinationSummary = {
		destinationCodes: [],
		hotelIds: [],
	};

	const maxDest = Math.floor(Math.random() * 5) + 1;
	if (isMobile) {
		// pending Handle mobile if needed
		return cy.wrap(stateDestination);
	} else {
		return cy.get(container)
			.scrollIntoView()
			.should('be.visible')
			.then(() => onClickDOM(`${container} > button.dropdown-toggle`))
			.then(() =>
				cy
					.get(`${container} .dropdown-menu.show > .compositionarea_body div.checkbox`)
					.its('length')
			)
			.then((maxCount) => {
				const listIdxDest = generateUniqueRandomNumbers(maxDest, 1, maxCount).sort((a, b) => a - b);
				const selectionPromises: Array<Cypress.Chainable> = [];

				listIdxDest.forEach((idxDest) => {
					const selector = `${container} .dropdown-menu.show > .compositionarea_body div.checkbox:nth-child(${idxDest})`;

					const chain = cy
						.get(`${selector} > .checkbox-wrapper > .checkbox-input`)
						.should('not.be.checked')
						.then(() => {
							onClickDOM(
								`div.checkbox:nth-child(${idxDest}) > .checkbox-wrapper > .checkbox-tile > span`,
								`${container} .dropdown-menu.show > .compositionarea_body`,
								{ force: true }
							);

							return cy
								.get(`${selector} > .checkbox-wrapper > .checkbox-input`)
								.should('be.checked')
								.invoke('val')
								.then((val: string | number | string[] | undefined) => {
									if (typeof val === 'string') {
										const itemsDest = val.split('-');
										stateDestination.destinationCodes.push(itemsDest[0]);
										if (withHotelId) {
											stateDestination.hotelIds.push(itemsDest[1]);
										}
									}
								});
						});

					selectionPromises.push(chain);
				});

				return cy.wrap(null).then(() => {					
					return Cypress.Promise.all(selectionPromises).then(() => stateDestination);
				});
			})
			.then((result) => {
				onClickDOM(`${container} > .dropdown-menu.show > .btn-group-area > .save_btn`);
				return cy.wrap(result)
			});
	}
};

export const selectExactDate = (
  container: string,
  options?: {
    isMobile?: boolean;
    ensureVisible?: boolean;
    log?: boolean;
  }
): Cypress.Chainable<ExactDate> => {
  const {
    isMobile = false,
    ensureVisible = true,
    log = false,
  } = options ?? {};

  if (isMobile) {
    return cy.wrap({ startDate: '', endDate: '' });
  } else {

		const result: ExactDate = { startDate: '', endDate: '' };
		const maxTries: number = modeTest ? Math.floor(Math.random() * 12) : 12;

		return cy.get(container)
			.scrollIntoView()
			.should('be.visible')
			.then(() =>
				onClickDuringAvailable(
					'.month2 thead > tr.caption > th:nth-child(2) > span',
					container,
					{ isMobile, maxTries, log, ensureVisible }
				)
			)
			.then(() => cy.get(container).find('tbody .day.available').last().click())
			.then(() =>
				cy.get(container)
					.find('tbody .day.start-date')
					.eq(0)
					.find('div > span')
					.invoke('text')
			)
			.then((startDayText) =>
				cy.get('.day.start-date')
					.closest('table')
					.find('thead .caption .month-name')
					.eq(0)
					.invoke('text')
					.then((monthText) => {
						result.startDate = parseToISO(`${startDayText} ${monthText}`, 'DD MMM YYYY') || '';
						if (log) console.log('Start:', result.startDate);
					})
			)
			.then(() => cy.get(container).find('tbody .day.available').last().click())
			.then(() =>
				cy.get(container)
					.find('tbody .day.end-date')
					.eq(0)
					.find('div > span')
					.invoke('text')
			)
			.then((endDayText) =>
				cy.get('.day.end-date')
					.closest('table')
					.find('thead .caption .month-name')
					.eq(0)
					.invoke('text')
					.then((monthText) => {
						result.endDate = parseToISO(`${endDayText} ${monthText}`, 'DD MMM YYYY') || '';
						if (log) console.log('End:', result.endDate);
					})
			)
			.then(() => {
				return cy.wrap(result)
			});
	}
};

export const selectStateWeek = (
	container: string,
	options?: {
		isMobile?: boolean;
		ensureVisible?: boolean;
		log?: boolean;
	}
): Cypress.Chainable<StateWeek> => {
	const {
		isMobile = false,
    ensureVisible = true,
    log = false,
  } = options ?? {};
	
	const stateWeek: StateWeek = {
		midweek: true,
		weekend: true,
	}
	
	if(isMobile) {
		return cy.wrap(stateWeek);
	} else {		
		return cy.wrap(stateWeek);
	}
}

export const selectNumberNights = (
	container: string,
	options?: {
		isMobile?: boolean;
		ensureVisible?: boolean;
		log?: boolean;
	}
): Cypress.Chainable<number[]> => {
	const {
		isMobile = false,
    ensureVisible = true,
    log = false,
  } = options ?? {};
	
	let numNights: number[] = [];
	
	if(isMobile) {
		return cy.wrap(numNights);
	} else {		
		return cy.wrap(numNights);
	}
}

export const selectWholeMonths = (
	container: string,
	options?: {
		isMobile?: boolean;
		ensureVisible?: boolean;
		log?: boolean;
	}
): Cypress.Chainable<string[]> => {
	const {
		isMobile = false,
    ensureVisible = true,
    log = false,
  } = options ?? {};
	
	let wholeMonths: string[] = [];
	
	if(isMobile) {
		return cy.wrap(wholeMonths);
	} else {		
		return cy.wrap(wholeMonths);
	}
}

export const selectRange = (
	container: string,
	kindPicker: number,
	options?: {
		isMobile?: boolean;
		ensureVisible?: boolean;
		log?: boolean;
	}
): Cypress.Chainable<RangeSummary> => {
	const {
		isMobile = false,
		ensureVisible = true,
		log = false,
	} = options ?? {};
	
	let stateRange: RangeSummary = {
		startDate: '',
		endDate: '',
		midweek: false,
		weekend: false,
		numNights: [],
		wholeMonths: [],
	};
	
	if(isMobile) {
		return cy.wrap(stateRange);
	} else {
		return cy.get(container)
			.scrollIntoView()
			.should('be.visible')
			.then(() => onClickDOM(`${container} > button.dropdown-toggle`))
			// .then(() => onClickDOM(`${container} > .dropdown-menu.show > .nav-tabs .nav-link:nth-child(${kindPicker})`))
			.then(() => {
				const selectionPromises: Array<Cypress.Chainable> = [];
				let containerExact: string = `${container} > .dropdown-menu.show > .tab-content > .tab-pane.show .month-wrapper`,
					containerWeek: string = '',
					containerNights: string = '';
				if(kindPicker == 1) {
					selectionPromises.push(selectExactDate(containerExact, {log}).then(exactDate => {
						stateRange = {...stateRange, ...exactDate};
					}));
				} else if(kindPicker == 2) {
					selectionPromises.push(selectStateWeek(containerWeek, {log}).then(stateWeek => {
						stateRange = {...stateRange, ...stateWeek};
					}));
					selectionPromises.push(selectExactDate(containerExact, {log}).then(exactDate => {
						stateRange = {...stateRange, ...exactDate};
					}));
					selectionPromises.push(selectNumberNights(containerNights, {log}).then(numNights => {
						stateRange = {...stateRange, numNights};
					}));
				} else if(kindPicker == 3) {
					selectionPromises.push(selectStateWeek(containerWeek, {log}).then(stateWeek => {
						stateRange = {...stateRange, ...stateWeek};
					}));
					selectionPromises.push(selectWholeMonths(containerExact, {log}).then(wholeMonths => {
						stateRange = {...stateRange, wholeMonths};
					}));
					selectionPromises.push(selectNumberNights(containerNights, {log}).then(numNights => {
						stateRange = {...stateRange, numNights};
					}));
				}
				
				return cy.wrap(null).then(() => {
					return Cypress.Promise.all(selectionPromises).then(() => stateRange)
				})
			})
			.then((result) => {
				onClickDOM(`${container} > .dropdown-menu.show > .tab-content .tab-pane.show .compositionarea_footer .btn-group-area > .save_btn`);
				return cy.wrap(result)
			})
	}
}

export const selectPaxByRoom = (
	container: string,
	options?: {
		isMobile?: boolean;
		ensureVisible?: boolean;
		log?: boolean;
		withAges?: boolean;
	}
): Cypress.Chainable<CompositionSummary> => {
	const {
		isMobile = false,
		ensureVisible = true,
		log = false,
		withAges = false,
	} = options ?? {};

	let paxByRoom: CompositionSummary = {
		adults: 0,
		children: 0, 
		infants: 0,
		agesChildren: [],
		agesInfants: []
	};

	if(isMobile) {
		return cy.wrap(paxByRoom);
	} else {
		return cy.get(container)
			.should('be.visible')
			.then(() => {
				if (log) console.log('Resolved room:', container);
				const numClicks: number[] = generateUniqueRandomNumbers(6, 0, 5);
				const promiseClicks: Array<Cypress.Chainable> = [];
				promiseClicks.push(onClickDOM(homeSelectors.componentSearch.general.plusAdult, container, { log: modeTest, index: 0, repeat: numClicks[0], ensureVisible: true }));
				promiseClicks.push(onClickDOM(homeSelectors.componentSearch.general.minusAdult, container, { log: modeTest, index: 0, repeat: numClicks[0]-1, ensureVisible: true }));
				promiseClicks.push(onClickDOM(homeSelectors.componentSearch.general.plusChild, container, { log: modeTest, index: 0, repeat: numClicks[2], ensureVisible: true }));
				promiseClicks.push(onClickDOM(homeSelectors.componentSearch.general.minusChild, container, { log: modeTest, index: 0, repeat: numClicks[3], ensureVisible: true }));
				promiseClicks.push(onClickDOM(homeSelectors.componentSearch.general.plusInfant, container, { log: modeTest, index: 0, repeat: numClicks[4], ensureVisible: true }));
				promiseClicks.push(onClickDOM(homeSelectors.componentSearch.general.minusInfant, container, { log: modeTest, index: 0, repeat: numClicks[5], ensureVisible: true }));
				return Promise.all(promiseClicks);
			})
			.then(() => {
				const promiseValues: Array<Cypress.Chainable> = [];
				promiseValues.push(cy.getValue(`${container} ${homeSelectors.componentSearch.general.valueAdult}`).then((valAdult: number) => paxByRoom.adults = valAdult));
				promiseValues.push(cy.getValue(`${container} ${homeSelectors.componentSearch.general.valueChild}`).then((valChild: number) => paxByRoom.children = valChild));
				promiseValues.push(cy.getValue(`${container} ${homeSelectors.componentSearch.general.valueInfant}`).then((valInfant: number) => paxByRoom.infants = valInfant));
				// if(withAges) { // pendings
				// 	paxByRoom.agesChildren = generateUniqueRandomNumbers(numClicks[3], 0, 12);
				// 	paxByRoom.agesInfants = generateUniqueRandomNumbers(numClicks[5], 0, 2);
				// }

				return Promise.all(promiseValues)
			})
			.then(() => {
				return cy.wrap(paxByRoom);
			})
	}
}

export const selectComposition = (
	container: string,
	options?: {
		isMobile?: boolean;
		ensureVisible?: boolean;
		log?: boolean;
	}
): Cypress.Chainable<CompositionSummary[]> => {
	const {
		isMobile = false,
		ensureVisible = true,
		log = false,
	} = options ?? {};

	let listPaxRoom: CompositionSummary[] = [];

	if (isMobile) {
		return cy.wrap(listPaxRoom);
	} else {
		const selectorPaxRooms = `${container} ${homeSelectors.componentSearch.general.paxOneRoom}`;

		return cy.get(container)
			.scrollIntoView()
			.should('be.visible')
			.then(() => onClickDOM(`${container} > button.dropdown-toggle`))
			.then(() => cy.get(selectorPaxRooms))
			.then(($rooms) => {
				const ctrooms = $rooms.length;
				if (log) console.log(`Found ${ctrooms} rooms`);

				const nativePromises: Array<Cypress.Chainable> = [];
				for (let i = 0; i < ctrooms; i++) {
					const containerPaxRoom = `${selectorPaxRooms}:nth-child(${i + 1})`;
					nativePromises.push(
						selectPaxByRoom(containerPaxRoom, { isMobile, log }).then((res) => {
							listPaxRoom.push(res);
						})
					);
				}
				return Promise.all(nativePromises).then(() => listPaxRoom);
			})
			.then(result => {
				onClickDOM(`${container} ${homeSelectors.componentSearch.general.confirmPax}`);
				return cy.wrap(result);
			})
	}
};

let searchOption: SearchOption = {
	destinations: { destinationCodes: [], hotelIds: [] },
	range: { startDate: '', endDate: '', midweek: false, weekend: false, numNights: [], wholeMonths: [] },
	composition: [],
};

export const selectBaseSearchOption = (
  selector: string,
  container: string,
  options?: {
    category?: string;
    isMobile?: boolean;
    index?: number;
    ensureVisible?: boolean;
    log?: boolean;
  }
): Cypress.Chainable<SearchOption>  => {
  const {
    category = '',
    isMobile = false,
    index = 0,
    ensureVisible = false,
    log = false,
  } = options ?? {};
	
	const searchOption: SearchOption = {
		typeFO: -1,
		destinations: { destinationCodes: [], hotelIds: [] },
		range: { startDate: '', endDate: '', midweek: false, weekend: false, numNights: [], wholeMonths: [] },
		composition: [],
	}
	
	if (log) console.log('selector:', selector, 'within container:', container);
	
	const target = container ? cy.get(container).should('be.visible').find(selector) : cy.get(selector);

  if (!isMobile) {
		let containerType: string = '', containerDestination: string = '', containeRange: string = '', containerComposition: string = '';
		let kindPicker: number = 1; //Math.floor(Math.random()*3)+1;
    switch (category) {
      case 'VP': {
		containerDestination = `${container} ${selector} ${homeSelectors.componentSearch.flyingCarpet.optionDestination(homeSelectors.componentSearch.general.optionsContainer)}`;
		containeRange = `${container}  ${selector} ${homeSelectors.componentSearch.flyingCarpet.optionRange(homeSelectors.componentSearch.general.optionsContainer)}`;
		containerComposition = `${container}  ${selector} ${homeSelectors.componentSearch.flyingCarpet.optionComposition(homeSelectors.componentSearch.general.optionsContainer)}`;
		return target.then(() => selectDestination(containerDestination, {withHotelId: false, isMobile, log: modeTest}))
			.then((listDest) => {
				searchOption.destinations = listDest;
				if(log) {
					console.log(listDest)
					cy.log(JSON.stringify(listDest))
				}
			})
			.wait(3000)
			.then(() => selectRange(containeRange, kindPicker, {isMobile, log: modeTest}))
			.then((range) => {
				searchOption.range = range;
				if(log) {
					console.log(range)
					cy.log(JSON.stringify(range))
				}
				return cy.wrap(searchOption);
			})
      }
      case 'FO': {
		// Setup for Flights Only
		containerType = `${container} ${selector} ${homeSelectors.componentSearch.flightOnly.typeFO}`;
		containerDestination = `${container} ${selector} ${homeSelectors.componentSearch.flightOnly.optionDestination(homeSelectors.componentSearch.general.optionsContainer)}`;
		containeRange = `${container} ${selector} ${homeSelectors.componentSearch.flightOnly.optionRange(homeSelectors.componentSearch.general.optionsContainer)}`;
		containerComposition = `${container} ${selector} ${homeSelectors.componentSearch.flightOnly.optionComposition(homeSelectors.componentSearch.general.optionsContainer)}`;
		return target
			.then(() => selectTypeFO(containerType, { isMobile, log: modeTest }))
			.then((typeFO) => {
				searchOption.typeFO = typeFO;
				if(log) {
					console.log(typeFO)
					cy.log(JSON.stringify(typeFO))
				}
			})
			.then(() => selectDestination(containerDestination, {withHotelId: false, isMobile, log: modeTest}))
			.then((listDest) => {
				searchOption.destinations = listDest;
				if(log) {
					console.log(listDest)
					cy.log(JSON.stringify(listDest))
				}
			})
			.wait(3000)
			.then(() => selectRange(containeRange, kindPicker, {isMobile, log: modeTest}))
			.then((range) => {
				searchOption.range = range;
				if(log) {
					console.log(range)
					cy.log(JSON.stringify(range))
				}				
			})
			.then(() => selectComposition(containerComposition, { isMobile, log: modeTest }))
			.then((composition) => {
				searchOption.composition = composition;
				if(log) {
					console.log(composition)
					cy.log(JSON.stringify(composition))
				}
			})
			.then(() => cy.wrap(searchOption))
      }
      case 'OT': {
        // Setup for Other
		return cy.wrap(searchOption);
      }
      default: {
        // Optionally handle unknown category
        if (log) console.warn(`Unhandled category: ${category}`);
		return cy.wrap(searchOption);
      }
    }
  } else {
    // Mobile-specific logic here
    if (log) console.log(`Running mobile mode for category: ${category}`);
		return cy.wrap(searchOption);
  }
};

export const selectSearchOptions = (pContainer: string, pCategory: string, isMobile: boolean=false): Cypress.Chainable<SearchOption> => {
	if(!isMobile) {
		let btnSearchCategory: string = "",
			activeContent: string ='';
		switch(pCategory){
			case 'VP':
				btnSearchCategory = homeSelectors.componentSearch.flyingCarpet.btnSearchCategory;
				activeContent = homeSelectors.componentSearch.flyingCarpet.containerSearchOption;
				break;
			case 'FO':
				btnSearchCategory = homeSelectors.componentSearch.flightOnly.btnSearchCategory;
				activeContent = homeSelectors.componentSearch.flightOnly.containerSearchOption;
				break;
			case 'OT':
				btnSearchCategory = ".nav-tabs > button[data-bs-target='#Organize_tour_packages']";
				activeContent = '#Organize_tour_packages.tab-pane';
				break;
		}
		
		return onClickDOM(btnSearchCategory, homeSelectors.componentSearch.general.searchTabMenu, { log: modeTest, index: 0, ensureVisible: true })
			.wait(5000)
			.then(() => selectBaseSearchOption(activeContent, homeSelectors.componentSearch.general.searchTabContent, {category: pCategory, isMobile, index:0, ensureVisible: true, log: modeTest }))
		
	} else {
		return cy.wrap({});
	}
}

export const maybeAssert = (flagSkip: boolean, $el:JQuery<HTMLElement>, assertion: () => Cypress.Chainable) => {
  return flagSkip ? cy.wrap($el) : assertion();
};

export const detectContaineData = (
	selector: string,
	list: Array<any>,
	options?: {
		index?: number,
		ensureVisible?: boolean,
	}
): Cypress.Chainable<any> => {	
	const {
		index = 0,
		ensureVisible = false,
	} = options ?? {};

	const el = cy.get(selector).eq(index);
	if (ensureVisible) el.scrollIntoView().should('be.visible');

	list.forEach((text) => {
		el.should('contain', text);
	});

	return el;
}