/// <reference types="cypress" />

import { getStatePage, parseQueryString, onClickDOM, formatWithDayName, getDateTimeFlight, updateStateHistory } from '../../../support/utils';
import { composition, weekdayNamesHe } from '../../../support/constants';
import { JSONValue } from '../../../support/types';
import dayjs from 'dayjs'
dayjs.locale('he');

const modeTest = Cypress.env('modeTest');
const modeShow = Cypress.env('modeShow');

const getInfoOnDetailHotel = (container: string, hotelId: string, flightId: string, extraData: {
	destinationData?: Record<string, any>;
	hotelData?: Record<string, any>;
	hotelDataProduct?: Record<string, any>;
}) => {
	const {
		destinationData = {},
		hotelData = {},
		hotelDataProduct = {},
	} = extraData ?? {};
	
	if(modeTest) console.log(extraData)
	cy.get(container).scrollIntoView().should('be.visible');
	
}

type SelectedHotel = {
	hotel: Record<string, any>;
	roomPrice: Record<string, any>;
}
const getSelectedHotel = (hotelDataProduct: any): Cypress.Chainable<SelectedHotel> => {
	const hotels: any[] = hotelDataProduct?.response?.body?.data?.hotel?.hotels ?? [];
	const resData = hotelDataProduct?.response?.body?.data ?? [];
	return cy.get('.israelhotel-gallery-box .searchresultbox')
		.scrollIntoView().should('be.visible')
		.getAttr('.israelhotel-gallery-box .israelhotel-list-box .product-one-room.selected', 'data-room-code')
		.then((pRoomCode: string) => {
			let roomCode = pRoomCode;
			cy.getAttr('.israelhotel-gallery-box .israelhotel-list-box .product-one-room.selected .board-increased-fare.selected', 'data-board-code').then((boardCode: string) => {
				if (modeTest) console.log(roomCode, boardCode)
				const hotel = hotels.find((el: any) => {
					return el.rooms.find((room: any) => room.code === roomCode)?.rates.find((rate: any) => rate.boardCode === boardCode);
				});
				if (!hotel) {
					return cy.wrap('error on find hotel')
				}
				const roomRateId = hotel.rooms.find((el: any) => el.code === roomCode)?.rates.find((el: any) => el.boardCode === boardCode)?.id ?? NaN;
				const roomPrice = resData?.package?.packages.find((el: any) => el.hotelRoomRef?.roomRateId === roomRateId)?.price ?? {};
				return cy.wrap({
					hotel,
					roomPrice
				});
			});
		});
}

export const checkProductDetail = (
	extraData? : {
		destinationData?: Record<string, any>;
		hotelData?: Record<string, any>;
		hotelDataProduct?: Record<string, any>;
	}
): Cypress.Chainable<any> => {
	
	const {
		destinationData = {},
		hotelData = {},
		hotelDataProduct = {},
	} = extraData ?? {};
	
	const container = '.product-detail-box .product-sticky-header';
	cy.get(container).scrollIntoView().should('be.visible');
	
	const dataRequest = hotelDataProduct?.request?.body ?? {},
		resData = hotelDataProduct?.response?.body?.data ?? [];
	
	// hotel room info
	cy.get('.israelhotel-gallery-box .searchresultbox')
		.scrollIntoView().should('be.visible')
		.then(() => getSelectedHotel(hotelDataProduct))
		.then(({hotel, roomPrice}) => {			
			cy.get(container).find('.pricebox .person-price').invoke('text').should('include', roomPrice?.avgPricePerPerson ?? NaN);
			cy.get(container).find('.pricebox .total-price span:nth-child(2)').invoke('text').should('include', roomPrice?.price ?? NaN);
			return cy.wrap(hotel);
		})
		.then((hotel: Record<string, any>) => {
			// hotel info
			cy.get(container).should('contain', hotel?.name ?? NaN);
			// cy.get(container).find('div:nth-child(2) > h6:nth-child(2) > span').should('have.text', hotel?.name ?? '');
			const adults = dataRequest?.passengerComposition?.adults ?? 0,
				children = dataRequest?.passengerComposition?.children ?? 0,
				infants = dataRequest?.passengerComposition?.infants ?? 0;
			const strAdult: string = adults > 1 ? `${adults} ${composition.adults}` :  composition.adult,
				strChild: string = children > 1 ? `${children} ${composition.children}` : composition.child,
				strInfant: string = infants > 1 ? `${infants} ${composition.intants}` : composition.infant;
			if (adults > 0) cy.get(container).should('contain', strAdult.toString());
			if (children > 0) cy.get(container).should('contain', strChild.toString());
			if (infants > 0) cy.get(container).should('contain', strInfant.toString());

			// if(adults>0) cy.get(container).find('div:nth-child(2) > p:nth-child(3) > span:nth-child(2) > span').should('have.text', strAdult);
			// if(children>0) cy.get(container).find('div:nth-child(2) > p:nth-child(3) > span:nth-child(3) > span').should('have.text', strChild);
			// if(infants>0) cy.get(container).find('div:nth-child(2) > p:nth-child(3) > span:nth-child(4) > span').should('have.text', strInfant);
		})
	
		
	//flight info
	cy.get('.israelhotel-gallery-box .searchresultbox')
		.scrollIntoView().should('be.visible')
		.getAttr('.israelhotel-gallery-box .searchresultbox', 'data-flight-id')
		.then((flightId: string) => {
			if(modeTest) console.log(flightId)
			const flight = resData?.flight?.itineraries.find(el => el.id == flightId);
			const departFlight = flight?.legs?.[0] ?? null,
				arriveFlight = flight?.legs?.[1] ?? null,
				start = dayjs(departFlight?.departureDate ?? 0),
				dateAdjustment = arriveFlight?.excerpt?.arrival?.dateAdjustment ?? 0,
				end = dayjs(arriveFlight?.departureDate ?? 0),
				nights = end.diff(start, 'day'),
				depart = `${departFlight?.excerpt?.departureDate ?? ''} ${departFlight?.excerpt?.departure?.time ?? ''}`,
				arriveDate = dayjs(arriveFlight?.departureDate ?? 0).add(dateAdjustment, 'day').format('YYYY-MM-DD'),
				arrive = `${arriveDate} ${arriveFlight?.excerpt?.arrival?.time ?? ''}`;
			
			// if(nights>0) cy.get(container).find('div:nth-child(2) > div:nth-child(4) > div > p:nth-child(1)').should('include.text', nights);
			// cy.get(container).find('div:nth-child(2) > div:nth-child(4) > div > p:nth-child(2) > span:nth-child(1)').should('include.text', formatWithDayName(start.toString()));
			// cy.get(container).find('div:nth-child(2) > div:nth-child(4) > div > p:nth-child(2) > span:nth-child(2)').should('include.text', formatWithDayName(end.toString()));
			
			
			if(nights>0) cy.get(container).should('contain', nights.toString());
			if (start) cy.get(container).should('contain', formatWithDayName(start.toString()));
			if (end) cy.get(container).should('contain', formatWithDayName(end.toString()));

			const timeItemsDepart = getDateTimeFlight(depart).split(' ');
			timeItemsDepart.forEach((item, index) => {
				// cy.get(container).find(`div:nth-child(4) > div:nth-child(2) > div > :nth-child(${2}) > span`).should('include.text', item);
				cy.get(container).should('contain', item);
			});
			const timeItemsArrive = getDateTimeFlight(arrive).split(' ');
			timeItemsArrive.forEach((item, index) => {
				// cy.get(container).find(`div:nth-child(4) > div:nth-child(3) > div > :nth-child(${2}) > span`).should('include.text', item);
				cy.get(container).should('contain', item);
			});
		})
	
	return cy.wrap('success : check the hotel detail info');
}

export const checkProductImageGallery = (
	extraData? : {
		destinationData?: Record<string, any>;
		hotelData?: Record<string, any>;
		hotelDataProduct?: Record<string, any>;
	}
): Cypress.Chainable<any> => {
	
	const {
		destinationData = {},
		hotelData = {},
		hotelDataProduct = {},
	} = extraData ?? {};

	const container = '.product-page-groups-area .israelhotel-gallery-box:nth-child(1)';
	cy.get(container).scrollIntoView().should('be.visible');

	const resData = hotelDataProduct?.response?.body?.data ?? {};

	return cy.get('.israelhotel-gallery-box .searchresultbox')
		.scrollIntoView().should('be.visible')
		.then(() => getSelectedHotel(hotelDataProduct))
		.then(({ hotel, roomPrice }) => { 
			// hotel info
			// cy.get(container).find('.header-text > div:nth-child(1) > h1').should('include.text', hotel?.name ?? '');
			cy.get(container).should('contain', hotel?.name ?? NaN);

			cy.get('.israelhotel-gallery-box .searchresultbox')
				.scrollIntoView().should('be.visible')
				.getAttr('.israelhotel-gallery-box .searchresultbox', 'data-flight-id')
				.then((flightId: string) => {
					const flight = resData?.flight?.itineraries.find(el => el.id == flightId);
					const departFlight = flight?.legs?.[0] ?? null,
						arriveFlight = flight?.legs?.[1] ?? null,
						start = dayjs(departFlight?.departureDate ?? 0),
						// dateAdjustment = arriveFlight?.excerpt?.arrival?.dateAdjustment ?? 0,
						end = dayjs(arriveFlight?.departureDate ?? 0);//.add(dateAdjustment, 'day');
				
					cy.get(container).find('div.flight-detail > p > span:nth-child(1)').should('include.text', formatWithDayName(start.toString()));
					cy.get(container).find('div.flight-detail > p > span:nth-child(2)').should('include.text', formatWithDayName(end.toString()));
				})

			return cy.wrap('success : check Image Gallery');
		})
}

export const checkProductFlight = (
	extraData? : {
		destinationData?: Record<string, any>;
		hotelData?: Record<string, any>;
		hotelDataProduct?: Record<string, any>;
	}
): Cypress.Chainable<any> => {
	
	const {
		destinationData = {},
		hotelData = {},
		hotelDataProduct = {},
	} = extraData ?? {};

	const container = '.product-page-groups-area .product-flight-outer-box';
	cy.get(container).scrollIntoView().should('be.visible');
	return cy.get(`${container} .searchresultbox`).scrollIntoView().should('be.visible').then(($el) => {
		const length = $el.find('.showmoreflights-btn').length;
		if (length > 0) {
			onClickDOM('.searchresultbox .showmoreflights-btn', container)
			cy.get('.showmoreflightsmodal.show').scrollIntoView().should('be.visible')
				.then(() => {
					cy.get('.searchresultbox_two').its('length').then((length: number) => {
						const numFlight = Math.floor(Math.random() * length) + 1;
						cy.get(`.showmoreflightsmodal.show .searchresultbox .searchresultbox_two:nth-child(${numFlight}) .selectflightright`)
							.scrollIntoView().should('be.visible')
							.then(() => {
								onClickDOM('a.btn-selectflight', `.showmoreflightsmodal.show .searchresultbox .searchresultbox_two:nth-child(${numFlight}) .selectflightright`, { ensureVisible: true })
									.wait(1000)
									.then(() => checkProductDetail(extraData))
									.then(() => cy.wrap('success : check changing flight'));
							})
						
					})
				})
		} else {
			return cy.wrap('error : no flight');
		}
	});	
}

export const checkProductSelectRoom = (
	extraData? : {
		destinationData?: Record<string, any>;
		hotelData?: Record<string, any>;
		hotelDataProduct?: Record<string, any>;
	}
): Cypress.Chainable<any> => {
	
	const {
		destinationData = {},
		hotelData = {},
		hotelDataProduct = {},
	} = extraData ?? {};

	const container = '.product-page-groups-area .room-outer-box';
	cy.get(container).scrollIntoView().should('be.visible');

	cy.get(`${container} .israelhotel-list-total`).scrollIntoView().should('be.visible').then(($el) => {
		const $rooms = $el.find('.product-one-room');
		if($rooms.length > 1) {
			const numRoom = Math.floor(Math.random() * ($rooms.length - 1)) + 1;
			if(modeTest) console.log(numRoom)
			cy.wrap($rooms.eq(numRoom))
				.find('.price-body > .rate-increased-and-select > button')
				.click({force:true})
				.then(() => {
					cy.get('.product-one-room.selected .media-body .board-increased-fare').filter(':visible').then($board => {
						if($board.length > 1) {
							const idxBoard = Math.floor(Math.random() * ($board.length - 1)) + 1;
							cy.wrap($board.eq(idxBoard)).click({force:true});
							cy.wait(500)
							.then(() => checkProductDetail(extraData));
						}						
					});
				});
		}
	})

	return cy.wrap('pending : check Room info')
}

export const testProductPage = (
	isMobile:boolean = false,
	testMode: boolean = false,
	extraData: {
		destinationData?: Record<string, string | number | boolean>;
		hotelData?: Record<string, string | number | boolean>;
		hotelDataProduct?: any;  // Type relaxed to avoid type conflicts
	} = {},
): Cypress.Chainable<string> => {
	if(testMode) {
		cy.log('It is Product page!!!');
		console.log('It is Product Page!!!')
	}
	
	return cy.wrap(null).then(() => getStatePage('productUrl'))
		.then(productUrl => {
			if (productUrl != null && productUrl != '' && productUrl != undefined) {
				// productUrl = 'https://new.flying.co.il/product-page?packageDates=2025-10-23%2C2025-10-26&hotelSupplier=Hotelbeds&flightDestCode=RHO&hotelCode=336853&paxByRoom=2%2C0%2C0&packCateg=vacation_pack&foOw=&outbound=&packageIds=&odyAgentCode=#hidden=false';

				// productUrl = 'https://new.flying.co.il/product-page?packageDates=2025-08-10,2025-08-14&hotelSupplier=Hotelbeds&flightDestCode=DXB&hotelCode=707852&paxByRoom=2,0,0&packCateg=vacation_pack&foOw=&outbound=&packageIds=&odyAgentCode=#hidden=false ';

				// productUrl = 'https://new.flying.co.il/product-page?packageDates=2025-10-14,2025-10-21&hotelSupplier=Hotelbeds&flightDestCode=AGP&hotelCode=14168&paxByRoom=2,0,0&packCateg=vacation_pack&foOw=&outbound=&packageIds=&odyAgentCode=#hidden=false';

				// productUrl = 'https://new.flying.co.il/product-page?packageDates=2025-10-19%2C2025-10-23&hotelSupplier=FlyingCarpet&flightDestCode=BCN&hotelCode=44847&paxByRoom=2%2C0%2C0&packCateg=vacation_pack&foOw=&outbound=&packageIds=218068&odyAgentCode=#hidden=false';

				// productUrl = "https://new.flying.co.il/product-page?packageDates=2025-10-23%2C2025-10-28&hotelSupplier=FlyingCarpet&flightDestCode=RHO&hotelCode=51250&paxByRoom=2%2C0%2C0&packCateg=vacation_pack&foOw=&outbound=&packageIds=220743&odyAgentCode=#hidden=false";
				
				cy.visit(productUrl);
				
				const urlParams: Record<string, any> = parseQueryString(productUrl);
				const category: string = urlParams.packCateg;
			
				cy.wait('@selectPackage').then((res) => {
					extraData.hotelDataProduct = res;
					cy.wrap(null)
						.then(() => {
							if (category == 'vacation_pack') {
								cy.get('.product-page-groups-area')
									.scrollIntoView()
									.should('be.visible')
									.then(() => checkProductDetail(extraData))
									.then(() => checkProductImageGallery(extraData))
									.then(() => checkProductFlight(extraData))
									.then(() => checkProductSelectRoom(extraData))
							} else if (category == 'OT') {
								return cy.wrap(productUrl);
							}
							
						})
						.then(() => {
							onClickDOM('#do-book-button').then(() => {
								return cy.location('pathname').should('eq', '/booking/passenger-detail')
									.then((currenPath: string) => {
										cy.url().then((currentUrl: string) => {
											updateStateHistory(1, {
												statePassenger: 'success',
												passengerUrl: currentUrl,
												time: new Date().toISOString(),
											})
										})
									})
							});
						})
				})
			} else {
				return cy.wrap('error on search result page')
			}
		})
}


