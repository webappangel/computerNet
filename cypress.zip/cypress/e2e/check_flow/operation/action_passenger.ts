import dayjs from "dayjs";
import { parseQueryString, updateStateHistory, getStatePage, formatHebrewDate } from "../../../support/utils";
import { composition } from "../../../support/constants";
import { detectContaineData } from "./general";

import { passengerSelectors } from "../../../selectors/passenter.css";

import { propFlightDepartureDate, propAirportDepart, propAirportArrive }  from '../../../support/composables/useFlightInfo'

const modeTest = Cypress.env('modeTest');
const modeShow = Cypress.env('modeShow');
const makePNR = Cypress.env('makePNR');


const checkPackageDetail = (
	extraData?: {
		destinationData?: Record<string, any>;
		hotelData?: Record<string, any>;
		hotelDataProduct?: Record<string, any>;
		passengerData?: Record<string, any>;
	}
) => {
	const {
		destinationData = {},
		hotelData = {},
		hotelDataProduct = {},
		passengerData = {},
	} = extraData ?? {};

	if(modeTest) console.log('data => ', extraData);
	// Hotel Name
    // cy.get('.order_hotel_detail_area .hotel-info-inner h4').eq(1)
  //   .should('contain', 'COOKS CLUB HERSONISSOS');
  
  // Pax Composition
  let numAdults: number = 0, numChildren: number = 0, numInfants: number = 0;
  passengerData?.paxByRoom?.forEach((pax: any) => {
    numAdults += pax.adults;
    numChildren += pax.children;
    numInfants += pax.infants;
  });
  if (modeTest) console.log('pax composition =>', numAdults, numChildren, numInfants);
  
  const paxData: Array<string> = [];
  paxData.push(numAdults > 1 ? `${numAdults} ${composition.adults}` : numAdults == 1 ? composition.adult : '');  paxData.push(numChildren > 1 ? `${numChildren} ${composition.children}` : numChildren == 1 ? composition.child : '');
  paxData.push(numInfants > 1 ? `${numInfants} ${composition.intants}` : numInfants ==1 ? composition.infant : '');
  detectContaineData(passengerSelectors.components.general.paxComposition.selLabelPax, paxData);
	
	// Flight Details (first direction)
  const departFlight = passengerData?.flight?.legs?.[0];
  const dataDepart: Array<any> = [];
  dataDepart.push(formatHebrewDate(propFlightDepartureDate(departFlight), { withWeekday: true }));
  dataDepart.push(propAirportDepart(departFlight));
  dataDepart.push(propAirportArrive(departFlight));
  
  cy.get(passengerSelectors.components.general.detailFlights.selDetailFlights).eq(0)
    .find(passengerSelectors.components.general.detailFlights.selBtnExpand)
    .scrollIntoView().should('be.visible').click();
	
	// Flight Details (return direction)
  const arriveFlight = passengerData?.flight?.legs?.[1];
  const arriveDate = dayjs(arriveFlight?.departureDate).add(arriveFlight?.excerpt?.arrival?.dateAdjustment ?? 0, 'day').format('YYYY-MM-DD');
  const dataArrive: Array<any> = [];
  dataArrive.push(formatHebrewDate(arriveDate, { withWeekday: true }));
  dataArrive.push(arriveFlight?.excerpt?.departure?.airport ?? NaN);
  dataArrive.push(arriveFlight?.excerpt?.arrival?.airport ?? NaN);
  detectContaineData(passengerSelectors.components.general.detailFlights.selDetailFlights, dataArrive, {index: 1});

  cy.get(passengerSelectors.components.general.detailFlights.selDetailFlights).eq(1)
    .find(passengerSelectors.components.general.detailFlights.selBtnExpand)
    .scrollIntoView().should('be.visible').click();
  
  // hotel checkin and checkout
  cy.get(passengerSelectors.components.flyingCarpet.detailHotel.contDetailHotel)
    .scrollIntoView().should('be.visible');
  // cy.get(passengerSelectors.components.flyingCarpet.detailHotel.selCheckIn)
  //   .scrollIntoView().should('be.visible')
  //   .should('contain',dayjs(departFlight?.departureDate).format('DD/MM'));
  // cy.get(passengerSelectors.components.flyingCarpet.detailHotel.selCheckOut)
  //   .scrollIntoView().should('be.visible')
  //   .should('contain',dayjs(arriveFlight?.departureDate).format('DD/MM'));
  detectContaineData(passengerSelectors.components.flyingCarpet.detailHotel.selCheckIn, [dayjs(departFlight?.departureDate).format('DD/MM')], {ensureVisible: true});
  detectContaineData(passengerSelectors.components.flyingCarpet.detailHotel.selCheckOut, [dayjs(arriveFlight?.departureDate).format('DD/MM')], {ensureVisible: true});

  // Price and Currency
  // cy.get('.total_box .total_box_footer span').last()
  //   .scrollIntoView().should('be.visible')
  //   .should('contain', passengerData?.finalPrice?.price ?? NaN);
  // detectContaineData(passengerSelectors.components.flyingCarpet)
  
  cy.get(passengerSelectors.components.general.paxItem.selPassenger).each(($item: JQuery<HTMLElement>, idx: number) => {
    // Use .then() to work with the actual DOM element
    cy.wrap($item).then(($el) => {
      if (idx > 0) {
        cy.wrap($el).find('.flightformbox_redio .flightformarrow').first().should('be.visible').click({force: true});
      }

      cy.wrap($el).within(() => {
        cy.get('.passenger-type > span').invoke('text').then((text) => {
          // cy.get('input[type="radio"][value="MR"]').check();
          let birthday = '';
          if (text.includes(composition.adult)) {
            birthday = dayjs().subtract(20, 'year').format('DD/MM/YYYY');
          } else if (text.includes(composition.child)) {
            birthday = dayjs().subtract(10, 'year').format('DD/MM/YYYY');
          } else if (text.includes(composition.infant)) {
            birthday = dayjs().subtract(1, 'year').format('DD/MM/YYYY');
          }
          cy.get('input[placeholder="DD/MM/YYYY"]').clear().type(birthday); // birthday
        });
        
        cy.get('input[placeholder="ם פרטי"]').clear().type('test'); // First Name
        cy.get('input[placeholder="שם משפחה"]').clear().type('test'); // Last Name
        cy.get('input[placeholder="אימייל"]').clear().type('test@test.com'); // Email
        cy.get('input[placeholder="מספר נייד"]').clear().type('123456789'); // Phone
      });
    });
  });

  cy.get('#go-book-next').click(); // To additional service

  cy.get('.passenger_details_main_area').scrollIntoView().should('be.visible');
  let totalLuggagePrice: number = 0;

  cy.get('.passenger_details_main_area').then(($container) => {
    const selectorLuggage: string = '.luggage-selection .one-flight-wrapper .justify-content-between .m-toggle > span[aria-disabled="false"]';
    const length: number = $container.find(selectorLuggage).length;
    if (length > 0) {
      $container.find(selectorLuggage).each((idx, $item) => { 
        cy.wrap($item).scrollIntoView().should('be.visible').click({force: true});
        cy.wrap($item).closest('.justify-content-between').find('div.label-weight').invoke('text').then((text) => {
          totalLuggagePrice += parseInt(text.match(/\$(\d+(?:\.\d+)?)/)?.[1] ?? '0');
          if(idx == length - 1) {
            cy.wait(200).get('.passenger_details_main_area .footing .total-price-letter').scrollIntoView().should('be.visible').should('contain', totalLuggagePrice);
          }
        });
      })
    }
  })
  

  cy.get('#go-book-next').click(); // To payer info

  cy.get('input[placeholder="ם פרטי"]').should('have.value', 'test');
  cy.get('input[placeholder="שם משפחה"]').should('have.value', 'test');
  cy.get('input[placeholder="אימייל"]').should('have.value', 'test@test.com');
  cy.get('input[placeholder="מספר נייד"]').should('have.value', '123456789');
  cy.get('input[placeholder="תעודת זהות"]').clear().type('000000018');

  cy.get('#go-book-next').click(); // To check order conditions

  cy.get('.flightbooking_form_middel .form-check.required-check')

  cy.get('.flightbooking_form_middel .form-check').each(($el, index) => {
    const isRequired = $el.hasClass('required-check');

    if (!isRequired) {
      cy.wrap($el).find('input[type="checkbox"]').check({force: true});
    }

  });

  cy.get('#go-book-next').click(); // To book

  cy.get('.needs-validation .alert-danger')
    .should('exist')
    .should('not.have.class', 'd-none');
  
  cy.get('.needs-validation .alert-danger .btn-close').click({force: true});

  cy.get('.flightbooking_form_middel .form-check').each(($el, index) => {
    const isRequired = $el.hasClass('required-check');
    if (isRequired) {
      cy.wrap($el).find('input[type="checkbox"]').check({force: true});
    }
  });

  if (makePNR) {
    // Danger :: if modeTest is false, PNR will be generated.

    // cy.get('#go-book-next').click(); // To book
    
    // cy.wait('@bookVacation').then((res) => {
    //   const resData = res.response?.body;
    //   if (resData?.status?.code == 3) {
    //     cy.get('.needs-validation .payment_area').should('be.visible').should('contain', resData?.totalPayment ?? NaN);
    //     cy.get('.total_box .total_box_footer span').last()
    //       .scrollIntoView().should('be.visible')
    //       .should('contain', resData?.totalPayment ?? NaN);
    //     updateStateHistory(1, {
    //       stateCredit2000: 'success',
    //       credit2000Url: resData?.paymentUrl ?? NaN,
    //       time: new Date().toISOString(),
    //     })
    //   }
    // });
  }

  
  // cy.wait('@cardCompleted').then((res) => {
  //   const resBooking = res.response?.body;
  //   console.log(resBooking);
  //   const bookProductData = JSON.parse(window.localStorage.getItem('book-product-data-server') ?? '');
  //   cy.wrap(bookProductData?.finalPrice?.price).should('contain', resBooking?.totalPayment);   

  // });
  	
  // cy.getIframeBody('iframe#payment-iframe').within(() => {
  //   cy.get('input[name="cardnumber"]').type('4580111300603050');
  //   cy.get('input[name="exp-date"]').type('12/30');
  //   cy.get('input[name="cvc"]').type('275');
  // });

}
const checkPackageDetailFO = (
	extraData?: {
		destinationData?: Record<string, any>;
		hotelData?: Record<string, any>;
		hotelDataProduct?: Record<string, any>;
		passengerData?: Record<string, any>;
	}
) => {
	const {
		destinationData = {},
		hotelData = {},
		hotelDataProduct = {},
		passengerData = {},
	} = extraData ?? {};

	console.log(extraData);
	// Hotel Name
    // cy.get('.order_hotel_detail_area .hotel-info-inner h4').eq(1)
  //   .should('contain', 'COOKS CLUB HERSONISSOS');
  
  let numAdults: number = 0, numChildren: number = 0, numInfants: number = 0;
  passengerData?.paxByRoom?.forEach((pax: any) => {
    numAdults += pax.adults;
    numChildren += pax.children;
    numInfants += pax.infants;
  });
  console.log(numAdults, numChildren, numInfants);
  
	const strAdult: string = numAdults > 1 ? `${numAdults} ${composition.adults}` :  numAdults ==1 ? composition.adult : '',
		strChild: string = numChildren > 1 ? `${numChildren} ${composition.children}` :  numChildren ==1 ? composition.child : '',
    strInfant: string = numInfants > 1 ? `${numInfants} ${composition.intants}` : numInfants ==1 ? composition.infant : '';
  
  // Pax Composition
  cy.get(passengerSelectors.general.selLabelPax)
    .should('contain', strAdult)
    .and('contain', strChild)
    .and('contain', strInfant);
	
	// Flight Details (first direction)
  const departFlight = passengerData?.flight?.legs?.[0];
  cy.get(passengerSelectors.general.selDetailFlights).eq(0)
    .should('contain', formatHebrewDate(departFlight?.departureDate, { withWeekday: true }))
    .and('contain', departFlight?.excerpt?.departure?.airport ?? NaN)
		.and('contain', departFlight?.excerpt?.arrival?.airport ?? NaN);
  cy.get(passengerSelectors.general.selDetailFlights).eq(0)
    .find(passengerSelectors.general.selBtnExpand)
    .scrollIntoView().should('be.visible').click();
	
	// Flight Details (return direction)
  const arriveFlight = passengerData?.flight?.legs?.[1] ?? null;
  if (arriveFlight) {
    const arriveDate = dayjs(arriveFlight?.departureDate).add(arriveFlight?.excerpt?.arrival?.dateAdjustment ?? 0, 'day').format('YYYY-MM-DD');
    cy.get(passengerSelectors.general.selDetailFlights).eq(1)
      .should('contain', formatHebrewDate(arriveDate, { withWeekday: true }))
      .and('contain', arriveFlight?.excerpt?.departure?.airport ?? NaN)
      .and('contain', arriveFlight?.excerpt?.arrival?.airport ?? NaN);
    cy.get(passengerSelectors.general.selDetailFlights).eq(1)
      .find(passengerSelectors.general.selBtnExpand)
      .scrollIntoView().should('be.visible').click();
  }

  // Price and Currency
  cy.get('.total_box .total_box_footer span').last()
    .scrollIntoView().should('be.visible')
    .should('contain', passengerData?.finalPrice?.price ?? NaN);
  
  cy.get('.flightbooking_form_rightbody .flightformbox .flightformbox_itembox').each(($item: JQuery<HTMLElement>, idx: number) => {
    // Use .then() to work with the actual DOM element
    cy.wrap($item).then(($el) => {
      if (idx > 0) {
        cy.wrap($el).find('.flightformbox_redio .flightformarrow').first().should('be.visible').click({force: true});
      }

      cy.wrap($el).within(() => {
        cy.get('.passenger-type > span').invoke('text').then((text) => {
          // cy.get('input[type="radio"][value="MR"]').check();
          let birthday = '';
          if (text.includes(composition.adult)) {
            birthday = dayjs().subtract(20, 'year').format('DD/MM/YYYY');
          } else if (text.includes(composition.child)) {
            birthday = dayjs().subtract(10, 'year').format('DD/MM/YYYY');
          } else if (text.includes(composition.infant)) {
            birthday = dayjs().subtract(1, 'year').format('DD/MM/YYYY');
          }
          cy.get('input[placeholder="DD/MM/YYYY"]').clear().type(birthday); // birthday
        });
        
        cy.get('input[placeholder="ם פרטי"]').clear().type('test'); // First Name
        cy.get('input[placeholder="שם משפחה"]').clear().type('test'); // Last Name
        cy.get('input[placeholder="אימייל"]').clear().type('test@test.com'); // Email
        cy.get('input[placeholder="מספר נייד"]').clear().type('123456789'); // Phone
      });
    });
  });

  cy.get('#go-book-next').click(); // To additional service

  cy.get('.passenger_details_main_area').scrollIntoView().should('be.visible');
  let totalLuggagePrice: number = 0;

  cy.get('.passenger_details_main_area').then(($container) => {
    const selectorLuggage: string = '.luggage-selection .one-flight-wrapper .justify-content-between .m-toggle > span[aria-disabled="false"]';
    const length: number = $container.find(selectorLuggage).length;
    if (length > 0) {
      $container.find(selectorLuggage).each((idx, $item) => { 
        cy.wrap($item).scrollIntoView().should('be.visible').click({force: true});
        cy.wrap($item).closest('.justify-content-between').find('div.label-weight').invoke('text').then((text) => {
          totalLuggagePrice += parseInt(text.match(/\$(\d+(?:\.\d+)?)/)?.[1] ?? '0');
          if(idx == length - 1) {
            cy.wait(200).get('.passenger_details_main_area .footing .total-price-letter').scrollIntoView().should('be.visible').should('contain', totalLuggagePrice);
          }
        });
      })
    }
  })
  

  cy.get('#go-book-next').click(); // To payer info

  cy.get('input[placeholder="ם פרטי"]').should('have.value', 'test');
  cy.get('input[placeholder="שם משפחה"]').should('have.value', 'test');
  cy.get('input[placeholder="אימייל"]').should('have.value', 'test@test.com');
  cy.get('input[placeholder="מספר נייד"]').should('have.value', '123456789');
  cy.get('input[placeholder="תעודת זהות"]').clear().type('000000018');

  cy.get('#go-book-next').click(); // To check order conditions

  cy.get('.flightbooking_form_middel .form-check.required-check')

  cy.get('.flightbooking_form_middel .form-check').each(($el, index) => {
    const isRequired = $el.hasClass('required-check');

    if (!isRequired) {
      cy.wrap($el).find('input[type="checkbox"]').check({force: true});
    }

  });

  cy.get('#go-book-next').click(); // To book

  cy.get('.needs-validation .alert-danger')
    .should('exist')
    .should('not.have.class', 'd-none');
  
  cy.get('.needs-validation .alert-danger .btn-close').click({force: true});

  cy.get('.flightbooking_form_middel .form-check').each(($el, index) => {
    const isRequired = $el.hasClass('required-check');
    if (isRequired) {
      cy.wrap($el).find('input[type="checkbox"]').check({force: true});
    }
  });

  if (makePNR) {
    // Danger :: if modeTest is false, PNR will be generated.

    // cy.get('#go-book-next').click(); // To book
    
    // cy.wait('@bookVacation').then((res) => {
    //   const resData = res.response?.body;
    //   if (resData?.status?.code == 3) {
    //     cy.get('.needs-validation .payment_area').should('be.visible').should('contain', resData?.totalPayment ?? NaN);
    //     cy.get('.total_box .total_box_footer span').last()
    //       .scrollIntoView().should('be.visible')
    //       .should('contain', resData?.totalPayment ?? NaN);
    //     updateStateHistory(1, {
    //       stateCredit2000: 'success',
    //       credit2000Url: resData?.paymentUrl ?? NaN,
    //       time: new Date().toISOString(),
    //     })
    //   }
    // });
  }

  
  // cy.wait('@cardCompleted').then((res) => {
  //   const resBooking = res.response?.body;
  //   console.log(resBooking);
  //   const bookProductData = JSON.parse(window.localStorage.getItem('book-product-data-server') ?? '');
  //   cy.wrap(bookProductData?.finalPrice?.price).should('contain', resBooking?.totalPayment);   

  // });
  	
  // cy.getIframeBody('iframe#payment-iframe').within(() => {
  //   cy.get('input[name="cardnumber"]').type('4580111300603050');
  //   cy.get('input[name="exp-date"]').type('12/30');
  //   cy.get('input[name="cvc"]').type('275');
  // });

}

export const testPassengerPage = (
	isMobile:boolean = false,
	testMode: boolean = false,
	extraData: {
		destinationData?: Record<string, string | number | boolean>;
		hotelData?: Record<string, string | number | boolean>;
		hotelDataProduct?: any;  // Type relaxed to avoid type conflicts
		passengerData?: any;
	} = {},
): Cypress.Chainable<string> => {
	if(testMode) {
		cy.log('It is Passenger page!!!');
		console.log('It is Passenger Page!!!')
	}
    return cy.wrap(null).then(() => getStatePage('passengerUrl'))
        .then(passengerUrl => {
          // passengerUrl = "https://new.flying.co.il/booking/passenger-detail?category=vacation_pack&packageSelectionId=feb5e04e-796c-4bdf-99d7-0b14cff76cd7&flightId=1-221101-1&storeId=3abdc78e-322c-42ff-9ecc-16fad998e5f9";
          if (passengerUrl != null && passengerUrl != '' && passengerUrl != undefined) {
            cy.visit(passengerUrl);

            const urlParams: Record<string, any> = parseQueryString(passengerUrl);
            const category: string = urlParams.category;
            cy.wait('@passengerDetail').then((res) => { 
              extraData.passengerData = JSON.parse(res.response?.body?.data ?? '{}');
              console.log(category);
              if (category == 'vacation_pack') {
                cy.get('.hotelplusflight.booking')
                  .scrollIntoView()
                  .should('be.visible')
                  .then(() => checkPackageDetail(extraData))
                // .then(() => checkProductImageGallery(extraData))
                // .then(() => checkProductFlight(extraData))
                // .then(() => checkProductSelectRoom(extraData))
              } else if (category == 'Flight_Only') {
                cy.get('.hotelplusflight.booking')
                  .scrollIntoView()
                  .should('be.visible')
                  .then(() => checkPackageDetailFO(extraData))
              } else if (category == 'OT') {
                return cy.wrap(passengerUrl);
              }
              
            })

			    } else {
            return cy.wrap('product page error');
          }
        })
}
