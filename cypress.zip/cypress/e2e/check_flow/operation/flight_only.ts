import {
	generateUniqueRandomNumbers,
	parseToISO,
	updateStateHistory,
	getStatePage,
	parseQueryString,
	onClickDOM,
	propFlightNumberFO,
	propFlightCityCode,
	propFlightDepartureDate,
	propFlightDepartureTime,
	propFlightArrivalDate,
	propFlightArrivalTime,
	strDateFormatHebrew,
	propDestCode
} from '../../../support/utils';

import { homeSelectors } from '../../../selectors/home.css.ts';
import { searchResultSelectors } from '../../../selectors/searchResult.css';

import {
	selectSearchOptions,
	maybeAssert,
} from './general';

const modeTest = Cypress.env('modeTest');
const modeShow = Cypress.env('modeShow');

import { SearchOption, JSONValue } from '../../../support/types';
import dayjs from 'dayjs';

let searchOption: SearchOption = {
	destinations: { destinationCodes: [], hotelIds: [] },
	range: { startDate: '', endDate: '', midweek: false, weekend: false, numNights: [], wholeMonths: [] },
	composition: [],
};

export const selectTypeFO = (
	container: string,
	options?: {
		isMobile?: boolean;
		ensureVisible?: boolean;
		log?: boolean;
	}
): Cypress.Chainable<any> => {
	const {
		isMobile = false,
		ensureVisible = true,
		log = false,
	} = options ?? {};

	let typeFO: number = -1;

	if(isMobile) {
		return cy.wrap(null);
	} else {
		console.log('selectTypeFO', container);
		typeFO = Math.floor(Math.random()*2)+1;
		return cy.get(container)
			.scrollIntoView()
			.should('be.visible')
			.then(() => onClickDOM(`${container} > div > :nth-child(${typeFO})`))
			.wait(3000)
			.then(() => {
				return cy.wrap(typeFO);
			})
	}
}

export const detectNumberOfFlights = (itineraries: Array<any>): Cypress.Chainable<any> => {
	cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.contSearchResult)
		.scrollIntoView()
		.should('be.visible')
		.then($container => {
			const $list = $container.find(searchResultSelectors.componentSearch.flightOnly.desktop.contOneFlight);
			const numFlights = $list.length;
			
			if (numFlights > 0) {
				// test the number of flights
				cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.selSearchResultLabel)
				.should('contain', $list?.length.toString());
				expect(numFlights).to.equal(itineraries?.length ?? 0);
			} else {
				return cy.wrap(null).then(() => {
					throw new Error('flight not found')
				})
			}
		})
	return cy.wrap(itineraries.length);
}

export const detectOneFlightInfo = ($el: any, dataItemFlight: Record<string, any>, typeFlight: number, isDetail: boolean = false): Cypress.Chainable<any> => {
	const jsonOneFlight: Record<string, any> = dataItemFlight?.legs?.[typeFlight] ?? {};
	return cy.wrap($el).scrollIntoView()
		.should('be.visible')
		.then(() => {
			return cy.wrap($el)
				.scrollIntoView()
				.should('be.visible')
				.then(() => {
					return maybeAssert(isDetail, $el, () => cy.wrap($el).should('contain', propFlightNumberFO(jsonOneFlight)));
				})
				.then(() => {
					return maybeAssert(isDetail, $el, () => cy.wrap($el).should('contain', propFlightCityCode(jsonOneFlight)));
				})
				.then(() => {
					const date = dayjs(propFlightDepartureDate(jsonOneFlight));
					return cy.wrap($el).should('contain', strDateFormatHebrew(date.toString(), 'day month'));
				})
				.then(() => {
					const date = dayjs(propFlightDepartureDate(jsonOneFlight));
					return cy.wrap($el).should('contain', strDateFormatHebrew(date.toString(), 'weekday'));
				})				
				.then(() => {
					const time = propFlightDepartureTime(jsonOneFlight).slice(0, 5);
					return cy.wrap($el).should('contain', time);
				})
				.then(() => {
					const date = dayjs(propFlightArrivalDate(jsonOneFlight));
					return cy.wrap($el).should('contain', strDateFormatHebrew(date.toString(), 'day month'));
				})
				.then(() => {
					const date = dayjs(propFlightArrivalDate(jsonOneFlight));
					return cy.wrap($el).should('contain', strDateFormatHebrew(date.toString(), 'weekday'));
				})
				.then(() => {
					const time = propFlightArrivalTime(jsonOneFlight).slice(0, 5);
					return cy.wrap($el).should('contain', time);
				})
				.then(() => {
					return cy.wrap($el).should('contain', propDestCode(jsonOneFlight, 'departure'));
				})
				.then(() => {
					return cy.wrap($el).should('contain', propDestCode(jsonOneFlight, 'arrival'));
				})
		})
}

export const detectPriceFlight = ($el: JQuery<HTMLElement>, dataItemFlight: Record<string, any>): Cypress.Chainable<any>  => {	
	const price: Record<string, any> = dataItemFlight?.excerpt ?? {};
	return cy.wrap($el).scrollIntoView()
		.should('be.visible')
		.and('contain', price?.totalPrice ?? NaN)
		.and('contain', price?.avgPricePerPerson ?? NaN)
}

export const detectItemFlight = (itineraries: Array<any>): Cypress.Chainable<any> => {
	const numFlights: number = itineraries.length;
	const flagExists: Array<boolean> = Array(numFlights).fill(false);
	return cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.contSearchResult)
		.find(searchResultSelectors.componentSearch.flightOnly.desktop.contOneFlight)
		.then(($list) => {
			const promiseFlightInfo: Array<Cypress.Chainable<any>> = [];
			$list.each((idx, $el) => {
				const flightId = $el.getAttribute('data-flight-id');
				if (!flightId) throw new Error("can't get the flight id");
				
				const idxFlight = itineraries.findIndex(flight => flight.id === flightId);
				const jsonOneFlight = idxFlight >= 0 ? itineraries[idxFlight] : null;
				if (idxFlight >= 0 && !flagExists[idxFlight]) {
					flagExists[idxFlight] = true;
				} else if (flagExists[idxFlight]) {
					throw new Error('already detected flight !!')
				} else if (idxFlight < 0) {
					throw new Error('flight not found!');
				}
				cy.wrap($el)
					.scrollIntoView()
					.should('be.visible')
					.within(() => {
						cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.selFlightInfo)
							.then($listflight => {
								$listflight.each((typeFlight, $flight) => {
									promiseFlightInfo.push(detectOneFlightInfo($flight, jsonOneFlight, typeFlight));
								})
							})
						cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.selPriceFlight)
							.then(($contPrice) => {
								promiseFlightInfo.push(detectPriceFlight($contPrice, jsonOneFlight))
							})
						cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.selExpandDetailFlight).click();
						cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.contDetailFlight)
							.should('have.class', 'show')
							.and('be.visible')
							.within(() => {
								cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.selDetailFlightInfo)
									.then($listflight => {
										$listflight.each((typeFlight, $flight) => {
											promiseFlightInfo.push(detectOneFlightInfo($flight, jsonOneFlight, typeFlight, true));
										})
									})
							})						
						
					})

			})
			return Promise.all(promiseFlightInfo)
		})
}

export const testSearchResultPageFO = (
	isMobile: boolean = false,
	testMode: boolean = false,
	extraData: Record<string, any> = {},
): Cypress.Chainable<any> => {
	if(testMode) {
		cy.log('It is Search Result page!!!');
		console.log('It is Search Result Page!!!');
	}
	return cy.wrap(null)
		.then(() => getStatePage('searchUrl'))
		.then(urlSearch => {

			cy.visit(urlSearch);
	
			cy.wait('@searchFlight').then((res) => {
				const resData = res.response?.body?.data ?? {};
				console.log('resData ==> ', resData);
				
				if(isMobile) {
					
				} else {
					console.log('searchFlight ==> ', res);
					const itineraries = resData?.itineraries ?? [];
					cy.wrap(null).then(() => detectNumberOfFlights(itineraries))
						.then((numFlights) => detectItemFlight(itineraries))
						.then(() => {
							const sel: string = `${searchResultSelectors.componentSearch.flightOnly.desktop.contSearchResult} ${searchResultSelectors.componentSearch.flightOnly.desktop.contOneFlight} ${searchResultSelectors.componentSearch.flightOnly.desktop.selGoBook}`;
							console.log(sel, document.querySelectorAll(sel));
							const idxFlight: number = Math.floor(Math.random() * itineraries.length);
							cy.get(searchResultSelectors.componentSearch.flightOnly.desktop.contSearchResult)
								.find(`${searchResultSelectors.componentSearch.flightOnly.desktop.contOneFlight} ${searchResultSelectors.componentSearch.flightOnly.desktop.selGoBook}`)
								.eq(idxFlight)
								.scrollIntoView()
								.should('be.visible')
								.click({force: true})
								.then(() => {
									return cy.location('pathname').should('eq', '/booking/passenger-detail')
										.then(() => {
											cy.url().then((currentUrl: string) => {
												updateStateHistory(1, {
													stateSearch: 'success',
													passengerUrl: currentUrl,
													time: new Date().toISOString(),
												})
												cy.log('testSearchResultPageFO ==> success');
											})
										})
								})
						})
					
				}
			})
		})
}

export const testHomePageFO = (
	isMobile:boolean = false,
	testMode:boolean = false,
	extraData: JSONValue = {}
): Cypress.Chainable<any> => {
	cy.visit('/');
	return cy.wait('@fetchDestinationData').then(() => {
		cy.wrap(null).then(() => selectSearchOptions(homeSelectors.componentSearch.general.searchOptionArea, 'FO', isMobile))
			.then((result) => {
				searchOption = result;
				if(modeShow) cy.wait(3000);
				
				cy.get('#main-filter-div')
					.scrollIntoView()
					.then(() => cy.get(homeSelectors.componentSearch.general.btnSearch))
					.eq(0)
					.invoke('attr', 'href')
					.then((link: string | undefined) => {
						if (!link) return;
						let data = {
								stateHome: 'success',
								// searchOption: searchOption,
								searchUrl: link,
								time: new Date().toISOString(),
							};
						updateStateHistory(1, data, 'create');
						
						// loadedPage('/', pCategory, isMobile, extraData)
						// loadedPage(link, pCategory, isMobile, extraData);
					})
			})
	});
}

