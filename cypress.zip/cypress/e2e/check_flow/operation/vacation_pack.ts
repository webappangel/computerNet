/// <reference types="cypress" />
import {
	SearchOption,
	JSONValue,
} from '../../../support/types';
import {
	updateStateHistory,
	getStatePage,
} from '../../../support/utils';

import {
	selectSearchOptions
} from './general';

import { homeSelectors } from '../../../selectors/home.css';

const modeTest = Cypress.env('modeTest');
const modeShow = Cypress.env('modeShow');

let searchOption: SearchOption = {
	destinations: { destinationCodes: [], hotelIds: [] },
	range: { startDate: '', endDate: '', midweek: false, weekend: false, numNights: [], wholeMonths: [] },
	composition: [],
};

export const checkHotel = (
	index: number,
	selector: string,
	options?: {
    isMobile?: boolean;
    ensureVisible?: boolean;
    log?: boolean;
  }
): Cypress.Chainable<number> => {
	const {
    isMobile = false,
    ensureVisible = true,
    log = false,
  } = options ?? {};
	
	let btnSelector = `${selector} .media-body > .body-left a.btn-secondery`;
	// onClickDOM(btnSelector, container, {log})
	
	return cy.wrap(0);
	
}

export const checkProductPage = (
	isMobile:boolean = false,
	testMode:boolean = false,
	extraData: JSONValue = {}
): Cypress.Chainable<any> => {
	let linkPassenger: string = '';
	return cy.wrap(null);
}

export const testHomePage = (
	isMobile:boolean = false,
	testMode:boolean = false,
	extraData: JSONValue = {}
): Cypress.Chainable<any> => {
	cy.visit('/');
	return cy.wait('@fetchDestinationData').then(() => {
		cy.wrap(null).then(() => selectSearchOptions(homeSelectors.componentSearch.general.searchOptionArea, 'VP', isMobile))
			.then((result) => {
				searchOption = result;
				if(modeShow) cy.wait(3000);
				
				cy.get('#main-filter-div')
					.scrollIntoView()
					.then(() => cy.get(homeSelectors.componentSearch.general.btnSearch))
					.eq(0)
					.invoke('attr', 'href')
					.then((link: string | undefined) => {
						if (!link) return;
						let data = {
								stateHome: 'success',
								// searchOption: searchOption,
								searchUrl: link,
								time: new Date().toISOString(),
							};
						updateStateHistory(1, data, 'create');
						
						// loadedPage('/', pCategory, isMobile, extraData)
						// loadedPage(link, pCategory, isMobile, extraData);
					})
			})
	});
}

export const testSearchResultPage = (
	isMobile:boolean = false,
	testMode: boolean = false,
	extraData: JSONValue = {},
): Cypress.Chainable<any> => {
	if(testMode) {
		cy.log('It is Search Result page!!!');
		console.log('It is Search Result Page!!!')
	}
	
	return cy.wrap(null).then(() => getStatePage('searchUrl'))
		.then(urlSearch => {

			cy.visit(urlSearch);
	
			cy.wait('@searchVacation').then((res) => {
				if(isMobile) {
					
				} else {
					cy.get('.resultmultipledateslist-area .resultmultipledateslist-left')
						.then($container => {
							const $list = $container.find('div.resultmultipledateslist-box .resultmultipledateslist-list .resultmultipledateslist-media');
							if ($list.length > 0) {
								const idxHotel: number = Math.floor(Math.random() * $list.length);
								cy.wrap($list.eq(idxHotel))
									.scrollIntoView()
									.should('be.visible')
									.then(($el) => {
										cy.wrap($el)
											.find('.media-body > .body-left a.btn-secondery')
											.invoke('attr', 'href')
											.then((link: string | undefined) => {
												if (!link) return;
												updateStateHistory(1, {
													stateSearch: 'succes',
													productUrl: link,
													time: new Date().toISOString(),
												})
												// loadedPage(link, pCategory, isMobile, extraData);
											})
									})
							}
						})
				}
			})
		})
}



export const test_____Page = (
	isMobile:boolean = false,
	testMode: boolean = false,
	extraData: JSONValue = {},
): Cypress.Chainable<any> => {
	if(modeTest) {
			cy.log('It is **** page!!!');
			console.log('It is **** Page!!!')
		}
	return cy.wrap(null);
}

/*
export const loadedPage = (toPath: string, pCategory: string, isMobile:boolean = false, extraData: JSONValue = {}): void => {
	
	let searchOption: SearchOption = {
		destinations: { destinationCodes: [], hotelIds: [] },
		range: { startDate: '', endDate: '', midweek: false, weekend: false, numNights: [], wholeMonths: [] },
		composition: {},
	};
	
	cy.location('pathname').then((currentUrl: string) => {
		if(currentUrl != toPath) cy.visit(toPath);
	})
	cy.wait(2000)
	
	cy.location('pathname').then((currentUrl: string) => {
		console.log('currentUrl => ', currentUrl)				
		if(currentUrl == '/'){
			cy.log('It is Home page!!!');
			
			const searchOptionArea: string = '.searchtabtotalbox';
			cy.wrap(null).then(() => selectSearchOptions(searchOptionArea, pCategory, isMobile))
				.then((result) => {
					searchOption = result;
					if(modeShow) cy.wait(3000);
					cy.get('#main-filter-div')
						.scrollIntoView()
						.then(() => cy.get('#nav-tabContent1 .tab-pane.active > .desktop_area_on .btnlarchesa'))
						.eq(0)
						.invoke('attr', 'href')
						.then((link: string | undefined) => {
							if (!link) return;
							let data = {
									state: 'success',
									searchOption: searchOption,
									searchUrl: link,
									time: new Date().toISOString(),
								};
							updateStateHistory(1, data, 'create');
							
							// loadedPage('/', pCategory, isMobile, extraData)
							loadedPage(link, pCategory, isMobile, extraData);
						})
				})
				
		} else if(currentUrl.includes('search-result')) {
			if(modeTest) {
				cy.log('It is Search Result page!!!');
				console.log('It is Search Result Page!!!')
			}
			
			cy.wait('@searchVacation').then(() => {
				let selector: string = '.resultmultipledateslist-area .resultmultipledateslist-left div.resultmultipledateslist-box .resultmultipledateslist-list .resultmultipledateslist-media';
				cy.get(selector)
					.eq(0)
					.scrollIntoView()
					.should('be.visible')
					.then(($el) => {
						cy.wrap($el)
							.find('.media-body > .body-left a.btn-secondery')
							.invoke('attr', 'href')
							.then((link: string | undefined) => {
								if (!link) return;
								updateStateHistory(1, {
									state: 'succes',
									productUrl: link,
									time: new Date().toISOString(),
								})
								loadedPage(link, pCategory, isMobile, extraData);
							})
					})
			})		
			
			
		} else if(currentUrl.includes('product-page')) {
			cy.log('It is Product Page!!!');			
			console.log('It is Product Page!!!')
			
			cy.wait('@selectPackage').then((hotelData) => {
				extraData.hotelDataProduct = hotelData;
				if(modeTest) console.log(extraData);
				cy.wrap(null)
				.then(() => {
					return checkProductPage(pCategory, {isMobile, log: modeTest, extraData});
				})
				.then((link) => {
					if(modeTest) {
						console.log(link);
						
						// updateStateHistory(1, {
							// state: 'succes',
							// passengerUrl: link,
							// time: new Date().toISOString(),
						// })
						// loadedPage('/', pCategory);
					}
				})
			})
			
		}
	})
}
*/
