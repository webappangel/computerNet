/// <reference types="cypress" />
// Import Cypress commands type definitions
import 'cypress-real-events'
import { PageNameType } from '../../src/type'
import { devices, apiListAll, maxResponseTime } from '../support/constants';
import { parseToISO } from '../support/utils';
import type { JSONValue } from '../support/types';
import { onClickDOM } from '../support/utils';

const modeTest = Cypress.env('modeTest');
const modeShow = Cypress.env('modeShow');

declare global {
  interface Window {
    __vike: {
      state: {
        landingData: {
          isLanding: boolean
        },
        pages: {
          pageName: PageNameType
        },
        searchData: any
      }
    }
  }
}

const timings = new Map<string, { start: number; end?: number }>();
const extraData: JSONValue = {
  hotelData: {},
  destinationData: {},
};

const checkHomePageComponents = (
  isMobile: boolean = false,
  testMode: boolean = false,
  extraData: JSONValue = {}
): Cypress.Chainable<string> => {
  // Wait for initial page load
  cy.get('.searchbannerarea', { timeout: maxResponseTime }).should('be.visible');

  // Wait for critical API responses
  cy.wait(['@fetchDestinationData', '@fetchInEffecHOmeV3'], { timeout: maxResponseTime });

  // Check banner slider after API load
  cy.get('.banner-swiper')
    .should('exist')
    .within(() => {
      cy.get('.swiper-slide').should('have.length.at.least', 1);
      cy.get('.swiper-pagination').should('exist');
    });

  // Check search controls after data load
  cy.get('.search-controls')
    .should('be.visible')
    .within(() => {
      cy.get('.directflightsonly_area').should('be.visible');
      cy.get('h1').should('be.visible');
    });

  return cy.wrap('success: checked home page components');
};

const checkDynamicContent = (
  isMobile: boolean = false,
  testMode: boolean = false,
  extraData: JSONValue = {}
): Cypress.Chainable<string> => {
  // Wait for deals data to load
  cy.wait('@fetchInEffecHOmeV3', { timeout: maxResponseTime }).then((interception) => {
    if (interception.response?.statusCode === 200) {
      // Check if deals are displayed
      cy.get('.DealsWrapper', { timeout: maxResponseTime })
        .should('exist')
        .and('be.visible')
        .within(() => {
          // Verify deal items are rendered
          cy.get('.deal-item').should('have.length.at.least', 1);
        });
    }
  });

  // Check destination data rendering
  cy.wait('@fetchDestinationData', { timeout: maxResponseTime }).then((interception) => {
    if (interception.response?.statusCode === 200) {
      // Verify destination options are populated
      cy.get('.destination-options')
        .should('exist')
        .and('not.be.empty');
    }
  });

  return cy.wrap('success: checked dynamic content');
};

const checkResponsiveLayout = (
  isMobile: boolean = false,
  testMode: boolean = false,
  extraData: JSONValue = {}
): Cypress.Chainable<string> => {
  // Wait for content to load
  cy.wait(['@fetchDestinationData', '@fetchInEffecHOmeV3'], { timeout: maxResponseTime });

  if (isMobile) {
    // Mobile-specific checks
    cy.get('.d-block.d-lg-none')
      .should('be.visible')
      .within(() => {
        cy.get('.mobile-search-panel').should('exist');
        cy.get('.mobile-deals-wrapper').should('exist');
      });
  } else {
    // Desktop-specific checks
    cy.get('.d-none.d-lg-block')
      .should('be.visible')
      .within(() => {
        cy.get('.desktop-search-panel').should('exist');
        cy.get('.desktop-deals-wrapper').should('exist');
      });
  }

  return cy.wrap('success: checked responsive layout');
};

export const testHomePage = (
  isMobile: boolean = false,
  testMode: boolean = false,
  extraData: JSONValue = {}
): Cypress.Chainable<string> => {
  // Check components
  checkHomePageComponents(isMobile, testMode, extraData);

  // Check dynamic content
  checkDynamicContent(isMobile, testMode, extraData);

  // Check responsive layout
  checkResponsiveLayout(isMobile, testMode, extraData);

  return cy.wrap('success: completed home page tests');
};

devices.forEach(device => {
  describe(`Home Page Testing on ${device.name}`, () => {
    const isMobile = device.name.includes('Mobile');
    let startTime: number;

    beforeEach(() => {
      // Intercept API calls
      apiListAll.forEach(({ alias, url, method }) => {
        cy.intercept({ method: method as 'GET' | 'POST', url }, (req) => {
          timings.set(alias, { start: Date.now() });
          req.on('response', (res) => {
            const timing = timings.get(alias);
            if (timing) {
              timing.end = Date.now();
              console.log(`${alias} ==> ${timing.end - timing.start}`);
              if (res.statusCode === 200) {
                switch(alias) {
                  case 'fetchDestinationData':
                    extraData.destinationData = res.body.data;
                    break;
                  case 'fetchInEffecHOmeV3':
                    extraData.hotelData = res.body.data;
                    break;
                }
              }
            }
          });
        }).as(alias);
      });

      // Set viewport
      if (Array.isArray(device.viewport)) {
        const [width, height] = device.viewport;
        cy.viewport(width, height);
      } else {
        cy.viewport(device.viewport);
      }

      // Visit home page
      cy.visit('/');
      startTime = performance.now();
    });

    it('should test home page functionality', () => {
      testHomePage(isMobile, modeTest, extraData);
    });

    afterEach(() => {
      const endTime = performance.now();
      const duration = endTime - startTime;
      expect(duration).to.be.lessThan(maxResponseTime);
    });
  });
});

describe('Home Page', () => {
  beforeEach(() => {
    // Visit the home page before each test
    cy.visit('/')
    // Wait for the page to load completely
    cy.get('.searchbannerarea').should('be.visible')
  })

  describe('Banner Section', () => {
    it('should display the banner slider', () => {
      cy.get('.banner-swiper').should('exist')
      cy.get('.swiper-slide').should('have.length.at.least', 1)
      cy.get('.swiper-pagination').should('exist')
    })

    it('should auto-slide the banner', () => {
      // Get the first active slide
      cy.get('.swiper-slide-active').as('firstSlide')
      // Wait for autoplay delay (5000ms + transition time)
      cy.wait(60000)
      // Check if slide has changed
      cy.get('@firstSlide').should('not.have.class', 'swiper-slide-active')
    })
  })

  describe('Search Panel', () => {
    it('should display the search controls section', () => {
      cy.get('.search-controls').should('be.visible')
      cy.get('.directflightsonly_area').should('be.visible')
    })

    it('should display the main heading', () => {
      cy.get('.directflightsonly_area h1').should('be.visible')
    })

    it('should have a functional landing page button', () => {
      cy.get('.go-to-landing-page-button').should('be.visible')
      cy.get('.go-to-landing-page-button').click()
      // Add assertions for the expected navigation behavior
    })
  })

  describe('Content Sections', () => {
    it('should load RecentSearchWrapper when not in landing page mode', () => {
      cy.get('.RecentSearchWrapper').should('exist')
    })

    it('should display DealsWrapper when deals are loaded', () => {
      // Wait for deals to load
      cy.get('.DealsWrapper', { timeout: 100000 }).should('be.visible')
    })

    it('should show WhyChooseFlyingCarpet section', () => {
      cy.get('.WhyChooseFlyingCarpet').should('be.visible')
    })

    it('should display CarouselLPDealList', () => {
      cy.get('.CarouselLPDealList').should('be.visible')
    })
  })

  describe('Responsive Behavior', () => {
    it('should adapt to mobile viewport', () => {
      // Set viewport to mobile size
      cy.viewport('iphone-x')
      
      // Check if mobile-specific elements are visible
      cy.get('.d-block.d-lg-none').should('be.visible')
      cy.get('.d-none.d-lg-block').should('not.be.visible')
    })

    it('should adapt to desktop viewport', () => {
      // Set viewport to desktop size
      cy.viewport(1920, 1080)
      
      // Check if desktop-specific elements are visible
      cy.get('.d-none.d-lg-block').should('be.visible')
      cy.get('.d-block.d-lg-none').should('not.be.visible')
    })
  })

  describe('Loading States', () => {
    it('should show content loader while page is mounting', () => {
      cy.visit('/')
      cy.get('[type="home-search"]').should('exist')
      // Content loader should disappear after page mount
      cy.get('[type="home-search"]').should('not.exist')
    })

    it('should show deal loader while deals are loading', () => {
      cy.visit('/')
      cy.get('[type="deal"]').should('exist')
      // Deal loader should disappear after deals load
      cy.get('[type="deal"]').should('not.exist')
    })
  })

  describe('Navigation', () => {
    it('should update page name on mount', () => {
      // This can be verified by checking the URL or page title
      cy.url().should('include', '/')
      // You might need to adjust this based on your actual implementation
      cy.title().should('include', 'Flying Carpet')
    })
  })

  describe('Initial Page Load', () => {
    it('should show content loader initially', () => {
      cy.get('content-loader[type="home-search"]').should('exist')
    })

    it('should show search panel after mounting', () => {
      // Wait for page to mount
      cy.get('SearchPanel').should('exist')
    })
  })

  describe('Regular Home Page State', () => {
    it('should show recent searches when not in landing page', () => {
      cy.get('RecentSearchWrapper').should('exist')
    })

    it('should show deals loader when deals are not loaded', () => {
      cy.get('.container content-loader[type="deal"]').should('exist')
    })

    it('should show deals wrapper when deals are loaded', () => {
      // Wait for deals to load
      cy.get('DealsWrapper').should('exist')
    })

    it('should show why choose flying carpet section', () => {
      cy.get('WhyChooseFlyingCarpet').should('exist')
    })

    it('should show carousel deals list', () => {
      cy.get('CarouselLPDealList').should('exist')
    })
  })

  describe('Landing Page State', () => {
    beforeEach(() => {
      // Set landing page state
      cy.window().then((win) => {
        win.__vike.state.landingData.isLanding = true
      })
    })

    it('should show popular places page in landing mode', () => {
      cy.get('PopularPlacePage').should('exist')
    })

    it('should hide regular home components in landing mode', () => {
      cy.get('RecentSearchWrapper').should('not.exist')
      cy.get('DealsWrapper').should('not.exist')
      cy.get('WhyChooseFlyingCarpet').should('not.exist')
      cy.get('CarouselLPDealList').should('not.exist')
    })
  })

  describe('Store Integration', () => {
    it('should update page name in store', () => {
      // Check initial state
      cy.window().then((win) => {
        expect(win.__vike.state.pages.pageName).to.equal(PageNameType.home)
      })
    })

    it('should initialize search data', () => {
      cy.window().then((win) => {
        expect(win.__vike.state.searchData).to.exist
      })
    })
  })

  describe('Component Loading States', () => {
    it('should handle deals loading state correctly', () => {
      // Test initial loading state
      cy.intercept('GET', '**/api/deals', {
        delay: 10000,
        fixture: 'deals.json'
      }).as('getDeals')

      cy.visit('/')
      
      // Check loading state
      cy.get('content-loader[type="deal"]').should('exist')
      
      // Check loaded state
      cy.wait('@getDeals')
      cy.get('DealsWrapper').should('exist')
    })

    it('should handle error states gracefully', () => {
      cy.intercept('GET', '**/api/deals', {
        statusCode: 500,
        body: { error: 'Failed to load deals' }
      }).as('getDealsError')

      cy.visit('/')
      
      // Should show error state or fallback
      cy.get('content-loader[type="deal"]').should('exist')
    })
  })
})

describe('Home Page Search Box', () => {
  devices.forEach(device => {
    const isMobile = device.name.includes('Mobile');
    context(`on ${device.name}`, () => {
      beforeEach(() => {
        // Set viewport
        if (Array.isArray(device.viewport)) {
          const [width, height] = device.viewport;
          cy.viewport(width, height);
        } else {
          cy.viewport(device.viewport);
        }
        cy.visit('/');
        // Wait for categories and search panel to load
        cy.get('.search-controls', { timeout: maxResponseTime }).should('be.visible');
        cy.get('.searchtab_menu', { timeout: maxResponseTime }).should('be.visible');
      });

      it('should switch between search tabs', () => {
        const tabs = [
          { selector: `button[data-bs-target="#pack"]`, label: 'Vacation package' },
          { selector: `button[data-bs-target="#fo"]`, label: 'flights' },
          { selector: `button[data-bs-target="#hotelIsrael"]`, label: 'Hotels in Israel' },
          { selector: `button[data-bs-target="#org"]`, label: 'Organized trips' },
        ];
        tabs.forEach(tab => {
          cy.get(tab.selector).click({ force: true });
          cy.get(tab.selector).should('have.class', 'active');
        });
      });

      it('should allow selecting a destination', () => {
        // Open the destination dropdown
        cy.get('.search-controls .btn-group .dropdown-toggle').first().click({ force: true });
        // Pick the first available destination
        cy.get('.destination-dropdown .compositionarea_body .row .checkbox').first().click({ force: true });
        // Save selection
        cy.get('.destination-dropdown .btn-group-area .save_btn').click({ force: true });
        // Dropdown should close
        cy.get('.destination-dropdown').should('not.be.visible');
      });

      it('should allow picking dates', () => {
        // Open the date dropdown
        cy.get('.search-controls .btn-group .dropdown-toggle').eq(1).click({ force: true });
        // Pick a date range (simulate by clicking two available days)
        cy.get('.calendar-dropdown .day.available').first().click({ force: true });
        cy.get('.calendar-dropdown .day.available').eq(1).click({ force: true });
        // Save selection
        cy.get('.calendar-dropdown .save_btn').click({ force: true });
        // Dropdown should close
        cy.get('.calendar-dropdown').should('not.be.visible');
      });

      it('should allow selecting guests/rooms', () => {
        // Open the composition dropdown
        cy.get('.search-controls .btn-group .dropdown-toggle').last().click({ force: true });
        // Increase adults by 1 (if possible)
        cy.get('.composition-dropdown .plus-btn').first().click({ force: true });
        // Save selection
        cy.get('.composition-dropdown .save_btn').click({ force: true });
        // Dropdown should close
        cy.get('.composition-dropdown').should('not.be.visible');
      });

      it('should perform a search and navigate to results', () => {
        // Fill in all required fields (destination, date, guests)
        cy.get('.search-controls .btn-group .dropdown-toggle').first().click({ force: true });
        cy.get('.destination-dropdown .compositionarea_body .row .checkbox').first().click({ force: true });
        cy.get('.destination-dropdown .btn-group-area .save_btn').click({ force: true });
        cy.get('.search-controls .btn-group .dropdown-toggle').eq(1).click({ force: true });
        cy.get('.calendar-dropdown .day.available').first().click({ force: true });
        cy.get('.calendar-dropdown .day.available').eq(1).click({ force: true });
        cy.get('.calendar-dropdown .save_btn').click({ force: true });
        cy.get('.search-controls .btn-group .dropdown-toggle').last().click({ force: true });
        cy.get('.composition-dropdown .plus-btn').first().click({ force: true });
        cy.get('.composition-dropdown .save_btn').click({ force: true });
        // Click the search button
        cy.get('.search-controls .SearchButton button, .search-controls button:contains("חפש")').first().click({ force: true });
        // Should navigate to search result page (URL or DOM change)
        cy.url({ timeout: maxResponseTime }).should('include', '/search-result');
      });
    });
  });
}); 